import argparse
import os
import numpy as np
import scipy.io as sio
import h5py

IMG_EXTENSIONS = [
    '.jpg', '.JPG', '.jpeg', '.JPEG',
    '.png', '.PNG', '.ppm', '.PPM', '.bmp', '.BMP',
]

def is_image_file(filename):
    return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir',help='path/to/LSVID/',default='/media/sdb1/zzj/LS-VID')
    parser.add_argument('--output_dir',help='path/to/save/database',default='./LSVID_database')
    args = parser.parse_args()

    os.system('mkdir -p %s'%(args.output_dir))
    info_dir=os.path.join(args.data_dir,'test/data')
    
    # Train
    train_imgs = []
    train_info = []
    global_start = 1
    data_dir = os.path.join(args.data_dir,'tracklet_train')
    ids = sorted(os.listdir(data_dir))
    for id in ids:
        images = sorted(os.listdir(os.path.join(data_dir,id)))
        for image in images:
            if is_image_file(image):
                train_imgs.append(os.path.abspath(os.path.join(data_dir,id,image)))
        #train_info
        intid = int(id)

        tracklet_idx=[]
        for image in images:
            tracklet_idx.append(image.split('.')[0].split('_')[0])
        tracklet_idx_set=list(set(tracklet_idx))
        tracklet_idx_set.sort(key=tracklet_idx.index)
        start=1
        for trackid in tracklet_idx_set:
            cur_info=[]
            length=tracklet_idx.count(trackid)

            end=length+start-1
            global_end =length+global_start-1
            cur_info.append(global_start)
            cur_info.append(global_end)
            cur_info.append(intid)
            #print(start,"  ",end)# start end
            camid = images[start].split('.')[0].split('_')[2]
            intcamid =int(camid)
            #print(camid)
            cur_info.append(intcamid)
            start=start+length
            global_start=global_start+length
            train_info.append(np.array(cur_info))


    train_imgs = np.array(train_imgs)
    train_info =np.array(train_info)

    

    np.savetxt(os.path.join(args.output_dir,'train_path.txt'),train_imgs,fmt='%s',delimiter='\n')


    # Test
    test_imgs = []
    data_dir = os.path.join(args.data_dir,'tracklet_test')
    ids = sorted(os.listdir(data_dir))
    for id in ids:
        images = sorted(os.listdir(os.path.join(data_dir,id)))
        for image in images:
            if is_image_file(image):
                test_imgs.append(os.path.abspath(os.path.join(data_dir,id,image)))
    test_imgs = np.array(test_imgs)

    np.savetxt(os.path.join(args.output_dir,'test_path.txt'),test_imgs,fmt='%s',delimiter='\n')


    # Val
    val_imgs = []
    data_dir = os.path.join(args.data_dir,'tracklet_val')
    ids = sorted(os.listdir(data_dir))
    for id in ids:
        images = sorted(os.listdir(os.path.join(data_dir,id)))
        for image in images:
            if is_image_file(image):
                val_imgs.append(os.path.abspath(os.path.join(data_dir,id,image)))
    val_imgs = np.array(val_imgs)

    np.savetxt(os.path.join(args.output_dir,'val_path.txt'),test_imgs,fmt='%s',delimiter='\n')

    ## process matfile

    val_info = sio.loadmat(os.path.join(info_dir,'info_val.mat'))['info_test']
    val_query_IDX = sio.loadmat(os.path.join(info_dir,'info_val.mat'))['query']

    test_info = h5py.File(os.path.join(info_dir,'info_test.mat'))['info_test']
    test_query_IDX = h5py.File(os.path.join(info_dir,'info_test.mat'))['query']
    test_info = np.array(test_info).T
    test_query_IDX = np.array(test_query_IDX).T

    # start from 0 (matlab starts from 1)    [frame_start_idx(start from 1),frame_end_idx(start from 1),pid(start from 0),camid(start from 1)]  
    train_info[:,0:2] = train_info[:,0:2]-1
    test_info[:,0:2] = test_info[:,0:2]-1
    val_info[:,0:2] = val_info[:,0:2]-1

    test_query_IDX=test_query_IDX-1
    val_query_IDX=val_query_IDX-1


    np.save(os.path.join(args.output_dir,'train_info.npy'),train_info)

    np.save(os.path.join(args.output_dir,'test_info.npy'),test_info)
    np.save(os.path.join(args.output_dir,'test_query_IDX.npy'),test_query_IDX)
    
    np.save(os.path.join(args.output_dir,'val_info.npy'),val_info)
    np.save(os.path.join(args.output_dir,'val_query_IDX.npy'),val_query_IDX)
    
