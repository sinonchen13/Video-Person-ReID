

# MARS
python3 evaluate.py --train_txt ./MARS_database/train_path.txt\
                    --train_info ./MARS_database/train_info.npy \
                    --test_txt ./MARS_database/test_path.txt \
                    --test_info ./MARS_database/test_info.npy \
                     --query_info ./MARS_database/query_IDX.npy \
                    --batch_size 64 \
                    --model_type 'resnet50_s1' \
                    --num_workers 8  \
                    --S 8  \
                    --latent_dim 2048 \
                    --temporal mean \
                    --stride 1 \
                    --load_ckpt ./ckpt_baseline_MARS/ckpt_best.pth \
                    --datasets Mars \
                    --random False
# LSVID
# python3 evaluate.py --train_txt ./LSVID_database/train_path.txt\
#                     --train_info ./LSVID_database/train_info.npy \
#                     --test_txt ./LSVID_database/test_path.txt \
#                     --test_info ./LSVID_database/test_info.npy \
#                     --query_info ./LSVID_database/query_IDX.npy \
#                     --batch_size 64 \
#                     --model_type 'resnet50_s1' \
#                     --num_workers 8  \
#                     --S 8  \
#                     --latent_dim 2048 \
#                     --temporal mean \
#                     --stride 1 \
#                     --load_ckpt ./R50_baseline_mean.pth \
#                     --datasets LSVID \
#                     --random False
# #DukeV
# python3 evaluate.py --train_txt ./DukeV_database/train_path.txt\
#                     --train_info ./DukeV_database/train_info.npy \
#                     --test_txt ./DukeV_database/gallery_path.txt \
#                     --test_info ./DukeV_database/gallery_info.npy \
#                     --query_info ./DukeV_database/query_IDX.npy \
#                     --batch_size 64 \
#                     --model_type 'resnet50_s1' \
#                     --num_workers 8  \
#                     --S 8  \
#                     --latent_dim 2048 \
#                     --temporal mean \
#                     --stride 1 \
#                     --load_ckpt ./R50_baseline_mean.pth \
#                     --datasets DukeV \
#                     --random False
#iLIDS
#python3 evaluate.py --batch_size 64 \
#                    --model_type 'resnet50_s1' \
#                    --num_workers 8  \
#                    --S 8  \
#                    --latent_dim 2048 \
#                    --temporal mean \
#                    --stride 1 \
#                    --load_ckpt ./Log/random/ckpt_random_iLIDS/ckpt_best.pth \
#                    --datasets iLIDS-VID \
#                    --random True

# #prid
#python3 evaluate.py --batch_size 64 \
#                    --model_type 'resnet50_s1' \
#                    --num_workers 8  \
#                    --S 8  \
#                    --latent_dim 2048 \
#                    --temporal mean \
#                    --stride 1 \
#                   --load_ckpt ./Log/random/ckpt_random_prid/ckpt_best.pth \
#                   --datasets prid \
#                    --random True
