from util import utils
from util.cmc import Video_Cmc,Video_Cmc_iLIDS_prid
from net import models
import parser
import sys
import random
from tqdm import tqdm
import numpy as np
import math
import iLIDS
import prid
import torch
import torch.nn as nn
import transforms as T
import torch.backends.cudnn as cudnn
cudnn.benchmark=True
import os
os.environ['CUDA_VISIBLE_DEVICES']='0,1'
torch.multiprocessing.set_sharing_strategy('file_system')

def validation_iLIDS_prid(network,query_dataloader,gallery_dataloader,args):
    network.eval()
    gallery_features = []
    gallery_labels = []
    gallery_cams = []
    with torch.no_grad():
        for c,data in enumerate(gallery_dataloader):
            #print(c)
            seqs = data[0].cuda()
            label = data[1]
            cams = data[2]
            
            feat = network(seqs)
            
            gallery_features.append(feat.cpu())
            gallery_labels.append(label)
            gallery_cams.append(cams)

    gallery_features = torch.cat(gallery_features,dim=0).numpy()
    gallery_labels = torch.cat(gallery_labels,dim=0).numpy()
    gallery_cams = torch.cat(gallery_cams,dim=0).numpy()

    query_features = []
    query_labels = []
    query_cams = []
    with torch.no_grad():
        for c,data in enumerate(query_dataloader):
            #print(c)
            seqs = data[0].cuda()
            label = data[1]
            cams = data[2]
            
            feat = network(seqs)
            
            query_features.append(feat.cpu())
            query_labels.append(label)
            query_cams.append(cams)

    query_features = torch.cat(query_features,dim=0).numpy()
    query_labels = torch.cat(query_labels,dim=0).numpy()
    query_cams = torch.cat(query_cams,dim=0).numpy()

    Cmc,mAP = Video_Cmc_iLIDS_prid(gallery_features,gallery_labels,gallery_cams,query_features,query_labels,query_cams,10000)
    network.train()

    return Cmc[0],mAP
def validation_DukeV_Mars_LSVID(network,dataloader,args):
    network.eval() 
    gallery_features = []
    gallery_labels = []
    gallery_cams = []
    with torch.no_grad():
        for c,data in enumerate(dataloader):
            seqs = data[0].cuda()
            label = data[1]
            #print(label)
            cams = data[2]
            feat = network(seqs)
            gallery_features.append(feat.cpu())
            gallery_labels.append(label)
            gallery_cams.append(cams)
            
    

    gallery_features = torch.cat(gallery_features,dim=0).numpy()
    cols,dims=gallery_features.shape
    
    gallery_labels = torch.cat(gallery_labels,dim=0).numpy()
    gallery_cams = torch.cat(gallery_cams,dim=0).numpy()
    if(args.datasets=='LSVID'):
        #remove added last one
        gallery_features = gallery_features[:cols-1,:]
        gallery_labels = gallery_labels[:cols-1]
        gallery_cams = gallery_cams[:cols-1]
    
    Cmc,mAP = Video_Cmc(gallery_features,gallery_labels,gallery_cams,dataloader.dataset.query_idx,10000)
    network.train()

    return Cmc[0],mAP

if __name__ == '__main__':
    #Parse args
    args = parser.parse_args()

    train_transform = T.Compose([T.Resize((256,128)),T.ToTensor(),T.Normalize(mean=[0.485,0.456,0.406],std=[0.229,0.224,0.225]),T.RandomErasing()])
    test_transform = T.Compose([T.Resize((256,128)),T.ToTensor(),T.Normalize(mean=[0.485,0.456,0.406],std=[0.229,0.224,0.225])])

    print('Start dataloader...')
    print('cur dataset: ',args.datasets)
    if args.datasets=="Mars":
        train_dataloader = utils.Get_Video_train_DataLoader(args.train_txt,args.train_info,train_transform,shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        num_class = train_dataloader.dataset.n_id
        test_dataloader = utils.Get_Video_test_DataLoader(args.test_txt,args.test_info,args.query_info,test_transform,batch_size=args.batch_size,\
                                                 shuffle=False,num_workers=args.num_workers,S=args.S,distractor=True,dataset=args.datasets)
    elif args.datasets=='LSVID':
        train_dataloader = utils.Get_Video_train_DataLoader(args.train_txt,args.train_info,train_transform,shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        num_class = train_dataloader.dataset.n_id
        test_dataloader = utils.Get_Video_test_DataLoader(args.test_txt,args.test_info,args.query_info,test_transform,batch_size=args.batch_size,\
                                                 shuffle=False,num_workers=args.num_workers,S=args.S,distractor=True,dataset=args.datasets)
    elif args.datasets=='DukeV':
        train_dataloader = utils.Get_Video_train_DataLoader(args.train_txt,args.train_info,train_transform,shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        num_class = train_dataloader.dataset.n_id
        test_dataloader = utils.Get_Video_test_DataLoader(args.test_txt,args.test_info,args.query_info,test_transform,batch_size=args.batch_size,\
                                                 shuffle=False,num_workers=args.num_workers,S=args.S,distractor=True,dataset=args.datasets)
    elif args.datasets=="iLIDS-VID":
        train_dataloader,num_class = iLIDS.Get_Video_train_DataLoader_iLIDS_VID(train_transform, shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        query_dataloader = iLIDS.Get_Video_query_DataLoader_iLIDS_VID(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
        gallery_dataloader=iLIDS.Get_Video_gallery_DataLoader_iLIDS_VID(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
    elif args.datasets=="prid":
        train_dataloader,num_class = prid.Get_Video_train_DataLoader_prid(train_transform, shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        query_dataloader = prid.Get_Video_query_DataLoader_prid(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
        gallery_dataloader=prid.Get_Video_gallery_DataLoader_prid(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
    print('End dataloader...\n')
    
    
    network = nn.DataParallel(models.CNN(args.latent_dim,num_class=num_class,stride=args.stride,tracklet_len=args.S,random=args.random).cuda())
    

    if args.load_ckpt is  None:
        print('No ckpt!')
        exit()
    else:
        state = torch.load(args.load_ckpt)
        network.load_state_dict(state,strict=True)
    for k,v in network.state_dict().items():
        print(k,v.shape)

    if(args.datasets=='DukeV' or args.datasets=='Mars' or args.datasets=='LSVID' ):
        cmc,map = validation_DukeV_Mars_LSVID(network,test_dataloader,args)
    if args.datasets == 'iLIDS-VID' or args.datasets == 'prid':
        cmc,map = validation_iLIDS_prid(network,query_dataloader,gallery_dataloader,args)

    print('CMC : %.4f , mAP : %.4f'%(cmc,map))
