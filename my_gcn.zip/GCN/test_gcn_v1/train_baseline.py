from util import utils
import parser
from net import models
import apex
import sys
import random
from tqdm import tqdm
import numpy as np
import math
from util.loss import TripletLoss
from util.cmc import Video_Cmc,Video_Cmc_iLIDS_prid
import iLIDS
import prid
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision.transforms import Compose,ToTensor,Normalize,Resize
import torch.backends.cudnn as cudnn
cudnn.benchmark=True
import os
import transforms as T
os.environ['CUDA_VISIBLE_DEVICES']='2,3'
torch.multiprocessing.set_sharing_strategy('file_system')

def validation_iLIDS_prid(network,query_dataloader,gallery_dataloader,args):
    network.eval()
    gallery_features = []
    gallery_labels = []
    gallery_cams = []
    with torch.no_grad():
        for c,data in enumerate(gallery_dataloader):
            #print(c)
            seqs = data[0].cuda()
            label = data[1]
            cams = data[2]
            
            feat = network(seqs)
            
            gallery_features.append(feat.cpu())
            gallery_labels.append(label)
            gallery_cams.append(cams)

    gallery_features = torch.cat(gallery_features,dim=0).numpy()
    gallery_labels = torch.cat(gallery_labels,dim=0).numpy()
    gallery_cams = torch.cat(gallery_cams,dim=0).numpy()

    query_features = []
    query_labels = []
    query_cams = []
    with torch.no_grad():
        for c,data in enumerate(query_dataloader):
            #print(c)
            seqs = data[0].cuda()
            label = data[1]
            cams = data[2]
            
            feat = network(seqs)
            
            query_features.append(feat.cpu())
            query_labels.append(label)
            query_cams.append(cams)

    query_features = torch.cat(query_features,dim=0).numpy()
    query_labels = torch.cat(query_labels,dim=0).numpy()
    query_cams = torch.cat(query_cams,dim=0).numpy()

    Cmc,mAP = Video_Cmc_iLIDS_prid(gallery_features,gallery_labels,gallery_cams,query_features,query_labels,query_cams,10000)
    network.train()

    return Cmc[0],mAP
def validation_DukeV_Mars_LSVID(network,dataloader,args):
    network.eval()
    
    
    gallery_features = []
    gallery_labels = []
    gallery_cams = []
    with torch.no_grad():
        for c,data in enumerate(dataloader):
            seqs = data[0].cuda()
            label = data[1]
            cams = data[2]
            feat = network(seqs)
            gallery_features.append(feat.cpu())
            gallery_labels.append(label)
            gallery_cams.append(cams)
            
    

    gallery_features = torch.cat(gallery_features,dim=0).numpy()
    cols,dims=gallery_features.shape
    
    gallery_labels = torch.cat(gallery_labels,dim=0).numpy()
    gallery_cams = torch.cat(gallery_cams,dim=0).numpy()
    if(args.datasets=='LSVID'):
        #remove added last one
        gallery_features = gallery_features[:cols-1,:]
        gallery_labels = gallery_labels[:cols-1]
        gallery_cams = gallery_cams[:cols-1]
    
    Cmc,mAP = Video_Cmc(gallery_features,gallery_labels,gallery_cams,dataloader.dataset.query_idx,10000)
    network.train()

    return Cmc[0],mAP


    
if __name__ == '__main__':
    #Parse args
    args = parser.parse_args()
    RANDOM_SEED=1997
    torch.manual_seed(RANDOM_SEED)
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    torch.cuda.manual_seed_all(RANDOM_SEED)
    # set transformation (H flip is inside dataset)
    train_transform = T.Compose([T.Resize((256,128)),T.ToTensor(),T.Normalize(mean=[0.485,0.456,0.406],std=[0.229,0.224,0.225]),T.RandomErasing()])
    test_transform = T.Compose([T.Resize((256,128)),T.ToTensor(),T.Normalize(mean=[0.485,0.456,0.406],std=[0.229,0.224,0.225])])

    print('Start dataloader...')
    print('cur dataset: ',args.datasets)
    if args.datasets=="Mars":
        train_dataloader = utils.Get_Video_train_DataLoader(args.train_txt,args.train_info,train_transform,shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        num_class = train_dataloader.dataset.n_id
        test_dataloader = utils.Get_Video_test_DataLoader(args.test_txt,args.test_info,args.query_info,test_transform,batch_size=args.batch_size,\
                                                 shuffle=False,num_workers=args.num_workers,S=args.S,distractor=True,dataset=args.datasets)
    elif args.datasets=='LSVID':
        train_dataloader = utils.Get_Video_train_DataLoader(args.train_txt,args.train_info,train_transform,shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        num_class = train_dataloader.dataset.n_id
        test_dataloader = utils.Get_Video_test_DataLoader(args.test_txt,args.test_info,args.query_info,test_transform,batch_size=args.batch_size,\
                                                 shuffle=False,num_workers=args.num_workers,S=args.S,distractor=True,dataset=args.datasets)
    elif args.datasets=='DukeV':
        train_dataloader = utils.Get_Video_train_DataLoader(args.train_txt,args.train_info,train_transform,shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        num_class = train_dataloader.dataset.n_id
        test_dataloader = utils.Get_Video_test_DataLoader(args.test_txt,args.test_info,args.query_info,test_transform,batch_size=args.batch_size,\
                                                 shuffle=False,num_workers=args.num_workers,S=args.S,distractor=True,dataset=args.datasets)
    elif args.datasets=="iLIDS-VID":
        train_dataloader,num_class = iLIDS.Get_Video_train_DataLoader_iLIDS_VID(train_transform, shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        query_dataloader = iLIDS.Get_Video_query_DataLoader_iLIDS_VID(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
        gallery_dataloader=iLIDS.Get_Video_gallery_DataLoader_iLIDS_VID(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
    elif args.datasets=="prid":
        train_dataloader,num_class = prid.Get_Video_train_DataLoader_prid(train_transform, shuffle=True,num_workers=args.num_workers,\
                                                        S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
        query_dataloader = prid.Get_Video_query_DataLoader_prid(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
        gallery_dataloader=prid.Get_Video_gallery_DataLoader_prid(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
    print('End dataloader...\n')
    
    network = nn.DataParallel(models.CNN(args.latent_dim,num_class=num_class,stride=args.stride,tracklet_len=args.S,random=args.random).cuda())
    
    
    if args.load_ckpt is not None:
        state = torch.load(args.load_ckpt)
        network.load_state_dict(state)
    
    # log 
    os.system('mkdir -p %s'%(args.ckpt))
    f = open(os.path.join(args.ckpt,args.log_path),'a')
    f.close()
    # Train loop
    # 1. Criterion
    criterion_triplet = TripletLoss('soft',True)

    criterion_ID = nn.CrossEntropyLoss().cuda()
    
    # 2. Optimizer
    parameters=[]
    parameters.append({'params': network.module.features.parameters()})
    parameters.append({'params': network.module.bottleneck.parameters()})
    parameters.append({'params': network.module.classifier.parameters()})
    if args.optimizer == 'sgd':
        optimizer = optim.SGD(parameters,lr = args.lr,momentum=0.9,weight_decay = 1e-4)
    else:
        optimizer = optim.Adam(parameters,lr = args.lr,weight_decay = 1e-5)
    if args.lr_step_size != 0:
        scheduler = optim.lr_scheduler.StepLR(optimizer, args.lr_step_size, 0.1)

    id_loss_list = []
    trip_loss_list = []
    track_id_loss_list = []

    best_cmc = 0
    for e in range(args.n_epochs):
        print('Epoch',e+1)
        # Validation
        if (e+1)%10 == 0:
            if(args.datasets=='DukeV' or args.datasets=='Mars' or args.datasets=='LSVID' ):
                cmc,map = validation_DukeV_Mars_LSVID(network,test_dataloader,args)
            if args.datasets == 'iLIDS-VID' or args.datasets == 'prid':
                cmc,map = validation_iLIDS_prid(network,query_dataloader,gallery_dataloader,args)
            print('CMC: %.4f, mAP : %.4f'%(cmc,map))
            f = open(os.path.join(args.ckpt,args.log_path),'a')
            f.write('epoch %d, rank-1 %f , mAP %f\n'%(e,cmc,map))
            if args.frame_id_loss:
                f.write('Frame ID loss : %r\n'%(id_loss_list))
            if args.track_id_loss:
                f.write('Track ID loss : %r\n'%(track_id_loss_list))
            f.write('Trip Loss : %r\n'%(trip_loss_list))

            id_loss_list = []
            trip_loss_list = []
            track_id_loss_list = []
            if cmc >= best_cmc:
                torch.save(network.state_dict(),os.path.join(args.ckpt,'ckpt_best.pth'))
                best_cmc = cmc
                f.write('best\n')
            f.close()
        # Training
        total_id_loss = 0 
        total_trip_loss = 0 
        total_track_id_loss = 0
        
        for i,data in enumerate(train_dataloader):
            seqs = data[0]
            labels = data[1].cuda()
            seqs = seqs.reshape((seqs.shape[0]*seqs.shape[1],)+seqs.shape[2:]).cuda()
            feat, output = network(seqs) 

            
            trip_loss = criterion_triplet(feat,labels,dis_func='eu')
            total_trip_loss += trip_loss.mean().item()
            total_loss = trip_loss.mean()           
            
            # Frame level ID loss
            if args.frame_id_loss == True:
                expand_labels = (labels.unsqueeze(1)).repeat(1,args.S).reshape(-1)
                id_loss = criterion_ID(output,expand_labels)
                total_id_loss += id_loss.item()
                coeff = 1
                total_loss += coeff*id_loss
            if args.track_id_loss == True:
                track_id_loss = criterion_ID(output,labels)
                total_track_id_loss += track_id_loss.item()
                coeff = 1
                total_loss += coeff*track_id_loss

            #####################
            optimizer.zero_grad()
            total_loss.backward()
            optimizer.step()
        
        
        if args.lr_step_size !=0:
            scheduler.step()

        avg_id_loss = '%.4f'%(total_id_loss/len(train_dataloader))
        avg_trip_loss = '%.4f'%(total_trip_loss/len(train_dataloader))
        avg_track_id_loss = '%.4f'%(total_track_id_loss/len(train_dataloader))
        print('Trip : %s , ID : %s , Track_ID : %s'%(avg_trip_loss,avg_id_loss,avg_track_id_loss))
        id_loss_list.append(avg_id_loss)
        trip_loss_list.append(avg_trip_loss)
        track_id_loss_list.append(avg_track_id_loss)
