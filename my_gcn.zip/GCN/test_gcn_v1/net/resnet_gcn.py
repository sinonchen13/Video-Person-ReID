import math
from torch.nn import functional as F
import numpy as np
import os
import torch
from torch import nn
from torch.nn import Parameter
##################### GCN Block #####################################
class GraphConvolution(nn.Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """

    def __init__(self, in_features, out_features, bias=False):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.Tensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.Tensor(1, 1, out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.matmul(input, self.weight)
        output = torch.matmul(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'
##################### Small Block ###################################

class Bottleneck(nn.Module):
    expansion = 4
    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, planes * 4, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * 4)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            residual = self.downsample(x)
        out += residual
        out = self.relu(out)

        return out
##############################################################################

############################ backbone model ##################################
class ResNet(nn.Module):
    def __init__(self, last_stride=1, block=Bottleneck, layers=[3, 4, 6, 3]):
        self.inplanes = 64
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3,
                               bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(block, 64, layers[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(
            block, 512, layers[3], stride=last_stride)

        interc=2048
        intercc=1024
        interccc=512
        #bt,c,h,w -> b,c t,h,w
        self.gcn11=GraphConvolution(interc, intercc)
        self.gcn12=GraphConvolution(intercc, interccc)
        self.w1=nn.Linear(interc,interc)
        self.gcn21=GraphConvolution(interc, intercc)
        self.gcn22=GraphConvolution(intercc, interccc)
        self.w2=nn.Linear(interc,interc)
        self.gcn41=GraphConvolution(interc, intercc)
        self.gcn42=GraphConvolution(intercc, interccc)
        self.w4=nn.Linear(interc,interc)
        self.gcnall1=GraphConvolution(interc, intercc)
        self.gcnall2=GraphConvolution(intercc, interccc)
        self.wall=nn.Linear(interc,interc)
        self.relu=nn.LeakyReLU(0.2)
        
        

        self.gap=nn.AdaptiveAvgPool3d(1)
        self.maxgap=nn.AdaptiveMaxPool1d(1)
    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )
        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes))
        return nn.Sequential(*layers)
    
    def forward(self, x):
        #1.每层全局建 不定的地方太多  
        
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.maxpool(x)  
        x = self.layer1(x)#bt,c,h,w
        x = self.layer2(x)#bt,c,h,w
        x = self.layer3(x)#bt,c,h,w
        x = self.layer4(x)#bt,c,h,w


        feat1_list=[]
        feat2_list=[]
        feat4_list=[]
        feat_all_list=[]

        num_stripes=1
        stripe_h = int(x.size(2) // num_stripes)
        for i in range(num_stripes):
            feat1 = F.avg_pool2d(x[:, :, i * stripe_h: (i + 1) * stripe_h, :],(stripe_h, x.size(-1))).squeeze()
            feat1_list.append(feat1)
            feat_all_list.append(feat1)

        num_stripes=2
        stripe_h = int(x.size(2) // num_stripes)
        for i in range(num_stripes):
            feat2 = F.avg_pool2d(x[:, :, i * stripe_h: (i + 1) * stripe_h, :],(stripe_h, x.size(-1))).squeeze()
            feat2_list.append(feat2)
            feat_all_list.append(feat2)

        num_stripes=4
        stripe_h = int(x.size(2) // num_stripes)
        for i in range(num_stripes):
            feat4 = F.avg_pool2d(x[:, :, i * stripe_h: (i + 1) * stripe_h, :],(stripe_h, x.size(-1))).squeeze()
            feat4_list.append(feat4)
            feat_all_list.append(feat4)

        #bt,c,1  bt,c,2  bt,c,4     t 2t 4t 建图   t+2t+4t建图
        feat1_list=torch.stack(feat1_list,2)    
        feat2_list=torch.stack(feat2_list,2) 
        feat4_list=torch.stack(feat4_list,2)
        feat_all_list=torch.stack(feat_all_list,2)

        
        bt,c,h,w=x.shape
        t=8
        b=bt//t
        x=x.view(b,t,c,h,w)
        x=x.permute(0,2,1,3,4).contiguous()
        x=self.gap(x).squeeze()# b,c
        x_ori=x

        feat1=feat1_list.view(b,t,c,-1)
        feat1=feat1.permute(0,2,1,3).contiguous()
        feat1=feat1.view(b,c,-1)
        feat1=feat1.permute(0,2,1).contiguous()

        feat2=feat2_list.view(b,t,c,-1)
        feat2=feat2.permute(0,2,1,3).contiguous()
        feat2=feat2.view(b,c,-1)
        feat2=feat2.permute(0,2,1).contiguous()

        feat4=feat4_list.view(b,t,c,-1)
        feat4=feat4.permute(0,2,1,3).contiguous()
        feat4=feat4.view(b,c,-1)
        feat4=feat4.permute(0,2,1).contiguous()

        featall=feat_all_list.view(b,t,c,-1)
        featall=featall.permute(0,2,1,3).contiguous()
        featall=featall.view(b,c,-1)
        featall=featall.permute(0,2,1).contiguous()


        adj1=torch.zeros(size=(b,t*1,t*1)).cuda()
        adj2=torch.zeros(size=(b,t*2,t*2)).cuda()
        adj4=torch.zeros(size=(b,t*4,t*4)).cuda()
        adjall=torch.zeros(size=(b,t*7,t*7)).cuda()
        
        for i in range(b):
            tmp1_adj=self.w1(feat1[i,:,:]).mm(self.w1(feat1[i,:,:]).t()) 
            tmp1_adj=tmp1_adj/(tmp1_adj.sum(1).view(tmp1_adj.size(0),-1))
            tmp1_adj=tmp1_adj+torch.eye(tmp1_adj.size(0),tmp1_adj.size(1)).cuda()
            tmp1_adj=gen_adj(tmp1_adj)
            adj1[i,:,:]=tmp1_adj

            tmp2_adj=self.w2(feat2[i,:,:]).mm(self.w2(feat2[i,:,:]).t()) 
            tmp2_adj=tmp2_adj/(tmp2_adj.sum(1).view(tmp2_adj.size(0),-1))
            tmp2_adj=tmp2_adj+torch.eye(tmp2_adj.size(0),tmp2_adj.size(1)).cuda()
            tmp2_adj=gen_adj(tmp2_adj)
            adj2[i,:,:]=tmp2_adj

            tmp4_adj=self.w4(feat4[i,:,:]).mm(self.w4(feat4[i,:,:]).t()) 
            tmp4_adj=tmp4_adj/(tmp4_adj.sum(1).view(tmp4_adj.size(0),-1))
            tmp4_adj=tmp4_adj+torch.eye(tmp4_adj.size(0),tmp4_adj.size(1)).cuda()
            tmp4_adj=gen_adj(tmp4_adj)
            adj4[i,:,:]=tmp4_adj

            tmpall_adj=self.wall(featall[i,:,:]).mm(self.wall(featall[i,:,:]).t()) 
            tmpall_adj=tmpall_adj/(tmpall_adj.sum(1).view(tmpall_adj.size(0),-1))
            tmpall_adj=tmpall_adj+torch.eye(tmpall_adj.size(0),tmpall_adj.size(1)).cuda()
            tmpall_adj=gen_adj(tmpall_adj)
            adjall[i,:,:]=tmpall_adj
        
        feat1=self.gcn11(feat1,adj1)
        feat1=self.relu(feat1)
        feat1=self.gcn12(feat1,adj1)

        feat2=self.gcn21(feat2,adj2)
        feat2=self.relu(feat2)
        feat2=self.gcn22(feat2,adj2)

        feat4=self.gcn41(feat4,adj4)
        feat4=self.relu(feat4)
        feat4=self.gcn42(feat4,adj4)

        featall=self.gcnall1(featall,adjall)
        featall=self.relu(featall)
        featall=self.gcnall2(featall,adjall)

        
        feat1=self.maxgap(feat1.permute(0,2,1)).squeeze()
        feat2=self.maxgap(feat2.permute(0,2,1)).squeeze()
        feat4=self.maxgap(feat4.permute(0,2,1)).squeeze()
        featall=self.maxgap(featall.permute(0,2,1)).squeeze()
        #print(feat1.size(),feat2.size(),feat4.size(),featall.size())
        feat_list=[feat1,feat2,feat4,featall]
        feat_list=torch.cat(feat_list,1)
        
        #print(feat_list.size())
        x=torch.cat([feat_list,x_ori],1)
        return x
    




def gen_adj(A):
    D = torch.pow(A.sum(1).float(), -0.5)
    D = torch.diag(D)
    adj = torch.matmul(torch.matmul(A, D).t(), D)
    return adj
if __name__ == "__main__":
    net = ResNet(last_stride=1)
    print(net)
    import torch

    x = net(torch.zeros(1, 3, 256, 128))
    print(x.shape)


