import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
import random
import net.resnet as res

def weights_init_kaiming(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_out')
        nn.init.constant_(m.bias, 0.0)
    elif classname.find('Conv') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_in')
        if m.bias is not None:
            nn.init.constant_(m.bias, 0.0)
    elif classname.find('BatchNorm') != -1:
        if m.affine:
            nn.init.constant_(m.weight, 1.0)
            nn.init.constant_(m.bias, 0.0)

def weights_init_classifier(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.normal_(m.weight, std=0.001)
        if m.bias:
            nn.init.constant_(m.bias, 0.0)


class Resnet50_s1(nn.Module): 
    def __init__(self,pooling=True,stride=1,tracklet_len=8,random=False):
        super(Resnet50_s1,self).__init__()
        original = models.resnet50(pretrained=True).state_dict()
        self.backbone = res.ResNet(last_stride=stride)
        for key in original:
            if key.find('fc') != -1:
                continue
            self.backbone.state_dict()[key].copy_(original[key])
        del original
        
        self.out_dim = 2048
        self.gap = nn.AdaptiveAvgPool3d(1)
        self.frames=tracklet_len
        self.random=random
    def forward(self,x):
        
        x1,x2,x3,x4 = self.backbone(x) #bt,c,h,w
        
       
        t=self.frames
        bt,c,h,w=x4.shape
        b=bt//t

        x4 = x4.view(b, t, c,h,w)
        x4 = x4.permute(0,2,1,3,4)

        _,c,h,w=x3.shape
        x3 = x3.view(b, t, c,h,w)
        x3 = x3.permute(0,2,1,3,4)

        _,c,h,w=x2.shape
        x2 = x2.view(b, t, c,h,w)
        x2 = x2.permute(0,2,1,3,4)

        _,c,h,w=x1.shape
        x1 = x1.view(b, t, c,h,w)
        x1 = x1.permute(0,2,1,3,4)
        # #random
        # if self.random=='True': 
                         
        #     h_ratio=0.3
        #     w_ratio=1
        #     x = x.permute(0,2,1,3,4)
        #     x= x.view(b,c,t,h,w)
        #     mask =  x.new_ones(x.size())
        #     for i in range(t): 
        #         h, w = x.size()[-2:]
        #         rh = round(h_ratio * h)
        #         rw = round(w_ratio * w)
        #         sx = random.randint(0,h-rh)
        #         sy = random.randint(0, w-rw)
        #         mask[:,:, i, sx:sx+rh, sy:sy+rw] = 0
        
        #     x = x * mask # b,c,t,h,w
            
        
        x1= self.gap(x1).squeeze()
        x2= self.gap(x2).squeeze()
        x3= self.gap(x3).squeeze()
        x4= self.gap(x4).squeeze()
        x=torch.cat([x1,x2,x3,x4],1)
        #print(x.size())
        # x = x.view(b, -1)                                       
        return x


class CNN(nn.Module):
    def __init__(self,out_dim,num_class=710,stride=1,tracklet_len=8,random=False):
        super(CNN,self).__init__()
        self.features = Resnet50_s1(stride=stride,tracklet_len=tracklet_len,random=random) 
       
        self.classifier = nn.Linear(out_dim,num_class, bias=False)
        self.classifier.apply(weights_init_classifier)
        self.bottleneck = nn.BatchNorm1d(out_dim)
        self.bottleneck.bias.requires_grad_(False)  # no shift
        self.bottleneck.apply(weights_init_kaiming)

    def forward(self,x,seg=None):
        
        x= self.features(x)
        bn = self.bottleneck(x)
        if self.training == True:
            output = self.classifier(bn)
            return x,output
        else:
            return bn

if __name__ == '__main__':
    model = Resnet50_s1()
    input = torch.ones(1,3,256,128)
    output = model(input)
    print(output.shape)
