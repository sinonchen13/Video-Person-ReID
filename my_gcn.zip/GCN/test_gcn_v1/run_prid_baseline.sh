

CKPT=ckpt_baseline_prid
python3 train_baseline.py  --batch_size 64 \
                          --n_epochs 300 --lr 0.0001 --lr_step_size 50 --optimizer adam --ckpt $CKPT --log_path loss.txt \
                          --model_type 'resnet50_s1' --num_workers 8 --class_per_batch 16 --track_per_class 4 --S 8 \
                          --latent_dim 2048 --temporal mean  --track_id_loss --stride 1 --random False --datasets prid
#random
#random True
#CKPT =ckpt_random_prid
