from __future__ import absolute_import

import torch
import math
import copy
import torchvision
import torch.nn as nn
from torch.nn import init
from torch.autograd import Variable
from torch.nn import functional as F
from torchvision import models

__all__ = ['ResNet50',]

def weights_init_kaiming(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        init.kaiming_normal_(m.weight.data, a=0, mode='fan_out')
        init.constant_(m.bias.data, 0.0)
    elif classname.find('Linear') != -1:
        init.kaiming_normal_(m.weight.data, a=0, mode='fan_out')
        init.constant_(m.bias.data, 0.0)
    elif classname.find('BatchNorm') != -1:
        init.normal_(m.weight.data, 1.0, 0.02)
        init.constant_(m.bias.data, 0.0)

def weights_init_classifier(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        init.normal_(m.weight.data, std=0.001)
        init.constant_(m.bias.data, 0.0)     

class Bottleneck(nn.Module):
    expansion = 4
    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, planes * 4, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * 4)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            residual = self.downsample(x)
        out += residual
        out = self.relu(out)

        return out

class ResNet(nn.Module):
    def __init__(self,last_stride=1, block=Bottleneck, layers=[3, 4, 6, 3]):
        self.inplanes = 64
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3,
                               bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(block, 64, layers[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, 512, layers[3], stride=last_stride)
            
    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )
        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes))
        return nn.Sequential(*layers)

    def forward(self, x):
    
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.maxpool(x)

        x = self.layer1(x)

        x = self.layer2(x)

        x = self.layer3(x)

        x = self.layer4(x)

        return x


#正反融合的me    
class MEModule(nn.Module):
    #n_segment=4 mars lsvid 
    #n_segment=8 prid ilidsvid 
    def __init__(self, channel, reduction=32, n_segment=4): 
        print("this is zfme3",n_segment)
        super(MEModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)
        #try 3 Parameter
        self.w1 = nn.Parameter(torch.full((1,1,1,1),0.33))
        self.w2 = nn.Parameter(torch.full((1,1,1,1),0.33))
        self.w3 = nn.Parameter(torch.full((1,1,1,1),0.33))
        # mars lsvid ilidsvid  0.33 0.33 0.33  
        # prid_nw              0.33 0.1 0.05
      
       
    def forward(self, x):

        #ME Module
        nt, c, h, w = x.size()
        Mbottleneck = self.Mconv1(x) 
        Mbottleneck = self.Mbn1(Mbottleneck)

        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:]) # b,t,c,h,w
        
        Mconv_bottleneck = self.Mconv2(Mbottleneck)    #相减前的卷积 
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])## b,t,c,h,w
        

        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, CMt_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

        __,rMt_fea1 = Mreshape_bottleneck.split([1, self.n_segment-1], dim=1)
        rCMt_fea1,__ = Mreshape_conv_bottleneck.split([self.n_segment-1, 1], dim=1) 

        Mt_fea2, __ = Mreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        __, CMt_fea2 = Mreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1) 

        __,rMt_fea2 = Mreshape_bottleneck.split([2, self.n_segment-2], dim=1)
        rCMt_fea2,__ = Mreshape_conv_bottleneck.split([self.n_segment-2, 2], dim=1) 

        Mt_fea3, __ = Mreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        __, CMt_fea3 = Mreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)

        __,rMt_fea3 = Mreshape_bottleneck.split([3, self.n_segment-3], dim=1)
        rCMt_fea3,__ = Mreshape_conv_bottleneck.split([self.n_segment-3, 3], dim=1)  

        diff_fea1 = CMt_fea1 - Mt_fea1  
        diff_fea2 = CMt_fea2 - Mt_fea2 
        diff_fea3 = CMt_fea3 - Mt_fea3 

        diff_fea1r = rCMt_fea1 - rMt_fea1  
        diff_fea2r = rCMt_fea2 - rMt_fea2 
        diff_fea3r = rCMt_fea3 - rMt_fea3    

        diff_fea1 = F.pad(diff_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        diff_fea2 = F.pad(diff_fea2, (0, 0, 0, 0, 0, 0, 0, 2), mode="constant", value=0)
        diff_fea3 = F.pad(diff_fea3, (0, 0, 0, 0, 0, 0, 0, 3), mode="constant", value=0)

        diff_fea1r = F.pad(diff_fea1r, (0, 0, 0, 0, 0, 0, 1, 0), mode="constant", value=0) 
        diff_fea2r = F.pad(diff_fea2r, (0, 0, 0, 0, 0, 0, 2, 0), mode="constant", value=0)
        diff_fea3r = F.pad(diff_fea3r, (0, 0, 0, 0, 0, 0, 3, 0), mode="constant", value=0)


        diff_fea1 = diff_fea1.view((-1,) + diff_fea1.size()[2:])  
        diff_fea2 = diff_fea2.view((-1,) + diff_fea2.size()[2:]) 
        diff_fea3 = diff_fea3.view((-1,) + diff_fea3.size()[2:])         

        diff_fea1r = diff_fea1r.view((-1,) + diff_fea1r.size()[2:])  
        diff_fea2r = diff_fea2r.view((-1,) + diff_fea2r.size()[2:]) 
        diff_fea3r = diff_fea3r.view((-1,) + diff_fea3r.size()[2:])     

        my1 = self.avg_pool(diff_fea1)  
        my2 = self.avg_pool(diff_fea2)  
        my3 = self.avg_pool(diff_fea3)  

        my1r = self.avg_pool(diff_fea1r)  
        my2r = self.avg_pool(diff_fea2r)  
        my3r = self.avg_pool(diff_fea3r)  


        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        my2 = self.Mconv3(my2) 
        my2 = self.Mbn3(my2) 
        my2 = self.sigmoid(my2) 
        my2 = my2 - 0.5

        my3 = self.Mconv3(my3) 
        my3 = self.Mbn3(my3) 
        my3 = self.sigmoid(my3) 
        my3 = my3 - 0.5

        my1r = self.Mconv3(my1r) 
        my1r = self.Mbn3(my1r) 
        my1r = self.sigmoid(my1r) 
        my1r = my1r - 0.5

        my2r = self.Mconv3(my2r) 
        my2r = self.Mbn3(my2r) 
        my2r = self.sigmoid(my2r) 
        my2r = my2r - 0.5

        my3r = self.Mconv3(my3r) 
        my3r = self.Mbn3(my3r) 
        my3r = self.sigmoid(my3r) 
        my3r = my3r - 0.5
       
        output = x + x * (my1.expand_as(x)*self.w1 + \
                          my2.expand_as(x)*self.w2 + \
                          my3.expand_as(x)*self.w3 + \
                          my1r.expand_as(x)*self.w1 + \
                          my2r.expand_as(x)*self.w2 + \
                          my3r.expand_as(x)*self.w3)
        
        return output

        #固定权重0.33
        #zfme_1half3    89.9 85.2
        # output = x + x * 0.33*(my1.expand_as(x) + \
        #                        my2.expand_as(x) + \
        #                        my3.expand_as(x) + \
        #                        my1r.expand_as(x) + \
        #                        my2r.expand_as(x) + \
        #                        my3r.expand_as(x))
        





class ResNet_Video_ME(nn.Module):
    def __init__(self,last_stride=1,block=Bottleneck,layers=[3,4,6,3],me_layers=[0,2,6,0]):
        self.inplanes = 64
        super().__init__()
       # print(me_layers)
        self.conv1 = nn.Conv2d(3,64,kernel_size=7,stride=2,padding=3,bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(kernel_size=3,stride=2,padding=1)

        self.layer1 = self._make_layer(block, 64, layers[0])
        me_idx = 0
        self.ME_1 = nn.ModuleList([MEModule(self.inplanes) for i in range(me_layers[me_idx])])
        self.ME_1_idx = sorted([layers[0]-(i+1) for i in range(me_layers[me_idx])])
        me_idx += 1

        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.ME_2 = nn.ModuleList([MEModule(self.inplanes) for i in range(me_layers[me_idx])])
        self.ME_2_idx = sorted([layers[1]-(i+1) for i in range(me_layers[me_idx])])
        me_idx += 1

        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)   
        self.ME_3 = nn.ModuleList([MEModule(self.inplanes) for i in range(me_layers[me_idx])]) 
        self.ME_3_idx =sorted( [layers[2]-(i+1) for i in range(me_layers[me_idx])])
        me_idx += 1

        self.layer4 = self._make_layer(block, 512, layers[3], stride=last_stride)
        self.ME_4 = nn.ModuleList([MEModule(self.inplanes) for i in range(me_layers[me_idx])])
        self.ME_4_idx = sorted([layers[3]-(i+1) for i in range(me_layers[me_idx])])
          
    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )
        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes))
        return nn.ModuleList(layers)

    def forward(self, x):
       
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.maxpool(x)
        
        # Layer 1
        ME1_counter = 0
        if len(self.ME_1_idx)==0: self.ME_1_idx=[-1]
        for i in range(len(self.layer1)):
            x = self.layer1[i](x)
            if i == self.ME_1_idx[ME1_counter]:
                x = self.ME_1[ME1_counter](x)
                ME1_counter+=1
        # Layer 2
        ME2_counter = 0
        if len(self.ME_2_idx)==0: self.ME_2_idx=[-1]
        for i in range(len(self.layer2)):
            x = self.layer2[i](x)
            if i == self.ME_2_idx[ME2_counter]:
                x = self.ME_2[ME2_counter](x)
                ME2_counter+=1
       
        # Layer 3
        ME3_counter = 0
        if len(self.ME_3_idx)==0: self.ME_3_idx=[-1]
        for i in range(len(self.layer3)):
            x = self.layer3[i](x)
            if i == self.ME_3_idx[ME3_counter]:
                x = self.ME_3[ME3_counter](x)
                ME3_counter+=1

        # Layer 4
        ME4_counter = 0
        if len(self.ME_4_idx)==0: self.ME_4_idx=[-1]
        for i in range(len(self.layer4)):
            x = self.layer4[i](x)
            if i == self.ME_4_idx[ME4_counter]:
                x = self.ME_4[ME4_counter](x)
                ME4_counter+=1

        return x

class ResNet50(nn.Module):
    def __init__(self,num_classes):
        super(ResNet50, self).__init__()

     
        self.backbone = ResNet_Video_ME()
        # self.backbone = ResNet()
        original = models.resnet50(pretrained=True).state_dict()
        for key in original:
            if key.find('fc') != -1:
               continue
            self.backbone.state_dict()[key].copy_(original[key])
        del original


        self.bn = nn.BatchNorm1d(2048)
        self.bn.apply(weights_init_kaiming)

        self.classifier = nn.Linear(2048, num_classes)
        self.classifier.apply(weights_init_classifier)



    def forward(self,x):
     
        b,c,t,h,w = x.shape
        x = x.permute(0,2,1,3,4).contiguous()
        x = x.view(b*t,c,h,w)
        x = self.backbone(x)
        x = F.max_pool2d(x, x.size()[2:])
        x = x.view(b, t, -1)
        if not self.training:
            return x
        x = x.mean(1)
        f = self.bn(x)
        y = self.classifier(f)

        return y, f
  
if __name__ =="__main__":
    # pass
    net = MEModule(2048)
    x = net(torch.ones(8*4, 2048,16,8))
    print(x.shape)
