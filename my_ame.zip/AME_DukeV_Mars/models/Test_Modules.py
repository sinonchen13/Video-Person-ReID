from __future__ import absolute_import

import torch
import math
import copy
import torchvision
import torch.nn as nn
from torch.nn import init
from torch.autograd import Variable
from torch.nn import functional as F
from torchvision import models


class AEModule(nn.Module):
    #reference by avg feature
    #reduction=32 ori
    def __init__(self, channel, reduction=2, n_segment=4): 
        print("this is AEModule")
        super(AEModule, self).__init__()
        self.channel = channel
        self.reduction = reduction

        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()
        
        ################--A Module--############################
        self.Aconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Abn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Aconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=self.channel//self.reduction,
            bias=False)

    
        self.Aconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        
        self.Abn3 = nn.BatchNorm2d(num_features=self.channel)

    def forward(self, x):
        #AE Module 
        nt, c, h, w = x.size()

        Abottleneck = self.Aconv1(x) #降维
        Abottleneck = self.Abn1(Abottleneck) #BN

        Areshape_bottleneck = Abottleneck.view((-1, self.n_segment) + Abottleneck.size()[1:]) # n,t,c,h,w
        Areshape_bottleneck = Areshape_bottleneck.mean(1) # n,c,h,w

        Aconv_bottleneck = self.Aconv2(Abottleneck)     
        Areshape_conv_bottleneck = Aconv_bottleneck.view((-1, self.n_segment) + Aconv_bottleneck.size()[1:]) # n,t,c,h,w

        ay = self.avg_pool(Areshape_bottleneck)# n,c,1,1

        ay = self.Aconv3(ay) #升维
        ay = self.Abn3(ay)  #BN
        ay = self.sigmoid(ay)  
        ay = ay - 0.5
        ay = torch.cat((ay,ay,ay,ay),dim=0)
        output = x + x * ay.expand_as(x) 
        return output

class AMEModule(nn.Module):
    #n_segment=4
    def __init__(self, channel, reduction=32, n_segment=8): # ori 32
        print("this is me3")
        super(AMEModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)

    def forward(self, x):
        # print(x.shape)
        #ME Module
        nt, c, h, w = x.size()
        Mbottleneck = self.Mconv1(x) 
        Mbottleneck = self.Mbn1(Mbottleneck)

        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:]) # b,t,c,h,w
        
        Mconv_bottleneck = self.Mconv2(Mbottleneck)    #相减前的卷积 
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])## b,t,c,h,w
        

        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, MtPlusone_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

        Mt_fea2, __ = Mreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        __, MtPlusone_fea2 = Mreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1)  

        Mt_fea3, __ = Mreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        __, MtPlusone_fea3 = Mreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)  

        diff_fea1 = MtPlusone_fea1 - Mt_fea1  
        diff_fea2 = MtPlusone_fea2 - Mt_fea2 
        diff_fea3 = MtPlusone_fea3 - Mt_fea3 

        diff_fea_pluszero1 = F.pad(diff_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        diff_fea_pluszero2 = F.pad(diff_fea2, (0, 0, 0, 0, 0, 0, 0, 2), mode="constant", value=0)
        diff_fea_pluszero3 = F.pad(diff_fea3, (0, 0, 0, 0, 0, 0, 0, 3), mode="constant", value=0)

        diff_fea_pluszero1 = diff_fea_pluszero1.view((-1,) + diff_fea_pluszero1.size()[2:])  #bt,c,h,w
        diff_fea_pluszero2 = diff_fea_pluszero2.view((-1,) + diff_fea_pluszero2.size()[2:])  #bt,c,h,w
        diff_fea_pluszero3 = diff_fea_pluszero3.view((-1,) + diff_fea_pluszero3.size()[2:])  #bt,c,h,w


        my1 = self.avg_pool(diff_fea_pluszero1)  # bt,c
        my2 = self.avg_pool(diff_fea_pluszero2)  # bt,c
        my3 = self.avg_pool(diff_fea_pluszero3)  # bt,c


        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        my2 = self.Mconv3(my2) 
        my2 = self.Mbn3(my2) 
        my2 = self.sigmoid(my2) 
        my2 = my2 - 0.5

        my3 = self.Mconv3(my3) 
        my3 = self.Mbn3(my3) 
        my3 = self.sigmoid(my3) 
        my3 = my3 - 0.5

        output = x + x * (1*my1.expand_as(x)+0.1*my2.expand_as(x)+0.01*my3.expand_as(x))
        return output

class AMECATModule(nn.Module):

    def __init__(self, channel, reduction=32, n_segment=4): 
        print("this is AMECATModule")
        super(AMECATModule, self).__init__()
        self.channel = channel//2
        self.reduction = reduction//2

        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()
        
        ################--A Module--############################
        self.Aconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Abn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Aconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=self.channel//self.reduction,
            bias=False)

        self.Apad = (0, 0, 0, 0, 0, 0, 0, 1)
    
        self.Aconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=1,
            kernel_size=1,
            bias=False)
        
        self.Abn3 = nn.BatchNorm2d(num_features=1)

        ######################--Motion Module--######################
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=self.channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)


    def forward(self, x):
        #AE Module 
        nt, c, h, w = x.size()
        ax = x[:,:c//2,:,:]
        mx = x[:,c//2:,:,:]
        Abottleneck = self.Aconv1(ax) 
        Abottleneck = self.Abn1(Abottleneck)
        Areshape_bottleneck = Abottleneck.view((-1, self.n_segment) + Abottleneck.size()[1:]) 
        At_fea, __ = Areshape_bottleneck.split([self.n_segment-1, 1], dim=1) 
        Aconv_bottleneck = self.Aconv2(Abottleneck)     
        Areshape_conv_bottleneck = Aconv_bottleneck.view((-1, self.n_segment) + Aconv_bottleneck.size()[1:])
        __, AtPlusone_fea = Areshape_conv_bottleneck.split([1, self.n_segment-1], dim=1) 
        plus_fea = AtPlusone_fea + At_fea 
        plus_fea_pluszero = F.pad(plus_fea, self.Apad, mode="constant", value=0) 
        plus_fea_pluszero = plus_fea_pluszero.view((-1,) + plus_fea_pluszero.size()[2:])  # bt,c,h,w
        ay = self.Aconv3(plus_fea_pluszero) 
        ay = self.Abn3(ay) 
        ay = self.sigmoid(ay) 
        ay = ay - 0.5
        output1 = ax + ax * ay.expand_as(ax) 
       
        #ME Module
        Mbottleneck = self.Mconv1(mx) 
        Mbottleneck = self.Mbn1(Mbottleneck)
        
        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:])
        Mconv_bottleneck = self.Mconv2(Mbottleneck)   
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])
        
        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, MtPlusone_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  
        Mt_fea2, __ = Mreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        __, MtPlusone_fea2 = Mreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1)  
        Mt_fea3, __ = Mreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        __, MtPlusone_fea3 = Mreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)  

        diff_fea1 = MtPlusone_fea1 - Mt_fea1  
        diff_fea2 = MtPlusone_fea2 - Mt_fea2 
        diff_fea3 = MtPlusone_fea3 - Mt_fea3 

        diff_fea_pluszero1 = F.pad(diff_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        diff_fea_pluszero2 = F.pad(diff_fea2, (0, 0, 0, 0, 0, 0, 0, 2), mode="constant", value=0)
        diff_fea_pluszero3 = F.pad(diff_fea3, (0, 0, 0, 0, 0, 0, 0, 3), mode="constant", value=0)

        diff_fea_pluszero1 = diff_fea_pluszero1.view((-1,) + diff_fea_pluszero1.size()[2:])  
        diff_fea_pluszero2 = diff_fea_pluszero2.view((-1,) + diff_fea_pluszero2.size()[2:])  
        diff_fea_pluszero3 = diff_fea_pluszero3.view((-1,) + diff_fea_pluszero3.size()[2:])  

        my1 = self.avg_pool(diff_fea_pluszero1)  
        my2 = self.avg_pool(diff_fea_pluszero2)  
        my3 = self.avg_pool(diff_fea_pluszero3)  
        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        my2 = self.Mconv3(my2) 
        my2 = self.Mbn3(my2) 
        my2 = self.sigmoid(my2) 
        my2 = my2 - 0.5

        my3 = self.Mconv3(my3) 
        my3 = self.Mbn3(my3) 
        my3 = self.sigmoid(my3) 
        my3 = my3 - 0.5

        output2 =  mx + mx * (1*my1.expand_as(mx)+0.3*my2.expand_as(mx)+0.1*my3.expand_as(mx))
        return torch.cat((output1,output2),1)
 
#加了反向的me 
class MEModule(nn.Module):
    #n_segment=4
    def __init__(self, channel, reduction=32, n_segment=4): # ori 32
        print("this is rme3")
        super(MEModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)

    def forward(self, x):

        #ME Module
        nt, c, h, w = x.size()
        Mbottleneck = self.Mconv1(x) 
        Mbottleneck = self.Mbn1(Mbottleneck)

        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:]) # b,t,c,h,w
        
        Mconv_bottleneck = self.Mconv2(Mbottleneck)    #相减前的卷积 
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])## b,t,c,h,w
        

        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, CMt_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

        __,rMt_fea1 = Mreshape_bottleneck.split([1, self.n_segment-1], dim=1)
        rCMt_fea1,__ = Mreshape_conv_bottleneck.split([self.n_segment-1, 1], dim=1) 

        Mt_fea2, __ = Mreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        __, CMt_fea2 = Mreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1) 

        __,rMt_fea2 = Mreshape_bottleneck.split([2, self.n_segment-2], dim=1)
        rCMt_fea2,__ = Mreshape_conv_bottleneck.split([self.n_segment-2, 2], dim=1) 

        Mt_fea3, __ = Mreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        __, CMt_fea3 = Mreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)

        __,rMt_fea3 = Mreshape_bottleneck.split([3, self.n_segment-3], dim=1)
        rCMt_fea3,__ = Mreshape_conv_bottleneck.split([self.n_segment-3, 3], dim=1)  

        diff_fea1 = CMt_fea1 - Mt_fea1  
        diff_fea2 = CMt_fea2 - Mt_fea2 
        diff_fea3 = CMt_fea3 - Mt_fea3 

        diff_fea1r = rCMt_fea1 - rMt_fea1  
        diff_fea2r = rCMt_fea2 - rMt_fea2 
        diff_fea3r = rCMt_fea3 - rMt_fea3         

        diff_fea_pluszero1 = F.pad(diff_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        diff_fea_pluszero2 = F.pad(diff_fea2, (0, 0, 0, 0, 0, 0, 0, 2), mode="constant", value=0)
        diff_fea_pluszero3 = F.pad(diff_fea3, (0, 0, 0, 0, 0, 0, 0, 3), mode="constant", value=0)

        rdiff_fea_pluszero1 = F.pad(diff_fea1r, (0, 0, 0, 0, 0, 0, 1, 0), mode="constant", value=0) 
        rdiff_fea_pluszero2 = F.pad(diff_fea2r, (0, 0, 0, 0, 0, 0, 2, 0), mode="constant", value=0)
        rdiff_fea_pluszero3 = F.pad(diff_fea3r, (0, 0, 0, 0, 0, 0, 3, 0), mode="constant", value=0)

        diff_fea_pluszero1 = diff_fea_pluszero1.view((-1,) + diff_fea_pluszero1.size()[2:])  #bt,c,h,w
        diff_fea_pluszero2 = diff_fea_pluszero2.view((-1,) + diff_fea_pluszero2.size()[2:])  #bt,c,h,w
        diff_fea_pluszero3 = diff_fea_pluszero3.view((-1,) + diff_fea_pluszero3.size()[2:])  #bt,c,h,w

        rdiff_fea_pluszero1 = rdiff_fea_pluszero1.view((-1,) + rdiff_fea_pluszero1.size()[2:])  #bt,c,h,w
        rdiff_fea_pluszero2 = rdiff_fea_pluszero2.view((-1,) + rdiff_fea_pluszero2.size()[2:])  #bt,c,h,w
        rdiff_fea_pluszero3 = rdiff_fea_pluszero3.view((-1,) + rdiff_fea_pluszero3.size()[2:])  #bt,c,h,w


        my1 = self.avg_pool(diff_fea_pluszero1)  # bt,c
        my2 = self.avg_pool(diff_fea_pluszero2)  # bt,c
        my3 = self.avg_pool(diff_fea_pluszero3)  # bt,c

        rmy1 = self.avg_pool(rdiff_fea_pluszero1)  # bt,c
        rmy2 = self.avg_pool(rdiff_fea_pluszero2)  # bt,c
        rmy3 = self.avg_pool(rdiff_fea_pluszero3)  # bt,c


        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        rmy1 = self.Mconv3(rmy1) 
        rmy1 = self.Mbn3(rmy1) 
        rmy1 = self.sigmoid(rmy1) 
        rmy1 = rmy1 - 0.5

        my2 = self.Mconv3(my2) 
        my2 = self.Mbn3(my2) 
        my2 = self.sigmoid(my2) 
        my2 = my2 - 0.5

        rmy2 = self.Mconv3(rmy2) 
        rmy2 = self.Mbn3(rmy2) 
        rmy2 = self.sigmoid(rmy2) 
        rmy2 = rmy2 - 0.5

        my3 = self.Mconv3(my3) 
        my3 = self.Mbn3(my3) 
        my3 = self.sigmoid(my3) 
        my3 = my3 - 0.5

        rmy3 = self.Mconv3(rmy3) 
        rmy3 = self.Mbn3(rmy3) 
        rmy3 = self.sigmoid(rmy3) 
        rmy3 = rmy3 - 0.5

        #Mars 1:0.3:0.1

        #split 7
        #ilids 1:0.05:0.05  7_2 88.7 100e

        #split 6
        #prid  1:0.3:0.05   97.8 
        # prid split 1:0.3:0.1
           
        output = x + x * (1*my1.expand_as(x)+0.3*my2.expand_as(x)+0.1*my3.expand_as(x)+1*rmy1.expand_as(x)+0.3*rmy2.expand_as(x)+0.1*rmy3.expand_as(x))
        return output

#只有正向的me
class MEModule(nn.Module):
    #n_segment=4
    def __init__(self, channel, reduction=32, n_segment=4): # ori 32
        print("this is me3")
        super(MEModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)

    def forward(self, x):

        #ME Module
        nt, c, h, w = x.size()
        Mbottleneck = self.Mconv1(x) 
        Mbottleneck = self.Mbn1(Mbottleneck)

        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:]) # b,t,c,h,w
        
        Mconv_bottleneck = self.Mconv2(Mbottleneck)    #相减前的卷积 
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])## b,t,c,h,w
        

        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, MtPlusone_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

        Mt_fea2, __ = Mreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        __, MtPlusone_fea2 = Mreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1)  

        Mt_fea3, __ = Mreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        __, MtPlusone_fea3 = Mreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)  

        diff_fea1 = MtPlusone_fea1 - Mt_fea1  
        diff_fea2 = MtPlusone_fea2 - Mt_fea2 
        diff_fea3 = MtPlusone_fea3 - Mt_fea3 

        diff_fea_pluszero1 = F.pad(diff_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        diff_fea_pluszero2 = F.pad(diff_fea2, (0, 0, 0, 0, 0, 0, 0, 2), mode="constant", value=0)
        diff_fea_pluszero3 = F.pad(diff_fea3, (0, 0, 0, 0, 0, 0, 0, 3), mode="constant", value=0)

        diff_fea_pluszero1 = diff_fea_pluszero1.view((-1,) + diff_fea_pluszero1.size()[2:])  #bt,c,h,w
        diff_fea_pluszero2 = diff_fea_pluszero2.view((-1,) + diff_fea_pluszero2.size()[2:])  #bt,c,h,w
        diff_fea_pluszero3 = diff_fea_pluszero3.view((-1,) + diff_fea_pluszero3.size()[2:])  #bt,c,h,w


        my1 = self.avg_pool(diff_fea_pluszero1)  # bt,c
        my2 = self.avg_pool(diff_fea_pluszero2)  # bt,c
        my3 = self.avg_pool(diff_fea_pluszero3)  # bt,c


        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        my2 = self.Mconv3(my2) 
        my2 = self.Mbn3(my2) 
        my2 = self.sigmoid(my2) 
        my2 = my2 - 0.5

        my3 = self.Mconv3(my3) 
        my3 = self.Mbn3(my3) 
        my3 = self.sigmoid(my3) 
        my3 = my3 - 0.5


           
        output = x + x * (1*my1.expand_as(x)+0.3*my2.expand_as(x)+0.1*my3.expand_as(x))
        return output

#正反融合的me 
class MEFBModule(nn.Module):
    #n_segment=4
    def __init__(self, channel, reduction=32, n_segment=4): # ori 32
        print("this is rme3")
        super(MEFBModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)

    def forward(self, x):

        #ME Module
        nt, c, h, w = x.size()
        Mbottleneck = self.Mconv1(x) 
        Mbottleneck = self.Mbn1(Mbottleneck)

        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:]) # b,t,c,h,w
        
        Mconv_bottleneck = self.Mconv2(Mbottleneck)    #相减前的卷积 
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])## b,t,c,h,w
        

        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, CMt_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

        __,rMt_fea1 = Mreshape_bottleneck.split([1, self.n_segment-1], dim=1)
        rCMt_fea1,__ = Mreshape_conv_bottleneck.split([self.n_segment-1, 1], dim=1) 

        Mt_fea2, __ = Mreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        __, CMt_fea2 = Mreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1) 

        __,rMt_fea2 = Mreshape_bottleneck.split([2, self.n_segment-2], dim=1)
        rCMt_fea2,__ = Mreshape_conv_bottleneck.split([self.n_segment-2, 2], dim=1) 

        Mt_fea3, __ = Mreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        __, CMt_fea3 = Mreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)

        __,rMt_fea3 = Mreshape_bottleneck.split([3, self.n_segment-3], dim=1)
        rCMt_fea3,__ = Mreshape_conv_bottleneck.split([self.n_segment-3, 3], dim=1)  

        diff_fea1 = CMt_fea1 - Mt_fea1  
        diff_fea2 = CMt_fea2 - Mt_fea2 
        diff_fea3 = CMt_fea3 - Mt_fea3 

        diff_fea1r = rCMt_fea1 - rMt_fea1  
        diff_fea2r = rCMt_fea2 - rMt_fea2 
        diff_fea3r = rCMt_fea3 - rMt_fea3    

        cat13 = torch.cat((diff_fea1,diff_fea3r),dim=1)
        cat22 = torch.cat((diff_fea2,diff_fea2r),dim=1)
        cat31 = torch.cat((diff_fea3,diff_fea1r),dim=1)

        cat13 = cat13.view((-1,) + cat13.size()[2:])  
        cat22 = cat22.view((-1,) + cat22.size()[2:]) 
        cat31 = cat31.view((-1,) + cat31.size()[2:])         

        my1 = self.avg_pool(cat13)  # bt,c
        my2 = self.avg_pool(cat22)  # bt,c
        my3 = self.avg_pool(cat31)  # bt,c

        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        my2 = self.Mconv3(my2) 
        my2 = self.Mbn3(my2) 
        my2 = self.sigmoid(my2) 
        my2 = my2 - 0.5

        my3 = self.Mconv3(my3) 
        my3 = self.Mbn3(my3) 
        my3 = self.sigmoid(my3) 
        my3 = my3 - 0.5
           
        output = x + x * (my1.expand_as(x)+my2.expand_as(x)+my3.expand_as(x))
        return output

'''
#正反考虑前后一帧的ME    top1:89.9% top5:96.8% top10:97.8% mAP:85.2%
class MEModule(nn.Module):
    #n_segment=4
    def __init__(self, channel, reduction=32, n_segment=4): # ori 32
        print("this is rme3")
        super(MEModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)

    def forward(self, x):

        #ME Module
        nt, c, h, w = x.size()
        Mbottleneck = self.Mconv1(x) 
        Mbottleneck = self.Mbn1(Mbottleneck)

        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:]) # b,t,c,h,w
        
        Mconv_bottleneck = self.Mconv2(Mbottleneck)    #相减前的卷积 
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])## b,t,c,h,w
        

        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, CMt_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

        __,rMt_fea1 = Mreshape_bottleneck.split([1, self.n_segment-1], dim=1)
        rCMt_fea1,__ = Mreshape_conv_bottleneck.split([self.n_segment-1, 1], dim=1) 

        # Mt_fea2, __ = Mreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        # __, CMt_fea2 = Mreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1) 

        # __,rMt_fea2 = Mreshape_bottleneck.split([2, self.n_segment-2], dim=1)
        # rCMt_fea2,__ = Mreshape_conv_bottleneck.split([self.n_segment-2, 2], dim=1) 

        # Mt_fea3, __ = Mreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        # __, CMt_fea3 = Mreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)

        # __,rMt_fea3 = Mreshape_bottleneck.split([3, self.n_segment-3], dim=1)
        # rCMt_fea3,__ = Mreshape_conv_bottleneck.split([self.n_segment-3, 3], dim=1)  

        diff_fea1 = CMt_fea1 - Mt_fea1  
        # diff_fea2 = CMt_fea2 - Mt_fea2 
        # diff_fea3 = CMt_fea3 - Mt_fea3 

        diff_fea1r = rCMt_fea1 - rMt_fea1  
        # diff_fea2r = rCMt_fea2 - rMt_fea2 
        # diff_fea3r = rCMt_fea3 - rMt_fea3         

        diff_fea_pluszero1 = F.pad(diff_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        # diff_fea_pluszero2 = F.pad(diff_fea2, (0, 0, 0, 0, 0, 0, 0, 2), mode="constant", value=0)
        # diff_fea_pluszero3 = F.pad(diff_fea3, (0, 0, 0, 0, 0, 0, 0, 3), mode="constant", value=0)

        rdiff_fea_pluszero1 = F.pad(diff_fea1r, (0, 0, 0, 0, 0, 0, 1, 0), mode="constant", value=0) 
        # rdiff_fea_pluszero2 = F.pad(diff_fea2r, (0, 0, 0, 0, 0, 0, 2, 0), mode="constant", value=0)
        # rdiff_fea_pluszero3 = F.pad(diff_fea3r, (0, 0, 0, 0, 0, 0, 3, 0), mode="constant", value=0)

        diff_fea_pluszero1 = diff_fea_pluszero1.view((-1,) + diff_fea_pluszero1.size()[2:])  #bt,c,h,w
        # diff_fea_pluszero2 = diff_fea_pluszero2.view((-1,) + diff_fea_pluszero2.size()[2:])  #bt,c,h,w
        # diff_fea_pluszero3 = diff_fea_pluszero3.view((-1,) + diff_fea_pluszero3.size()[2:])  #bt,c,h,w

        rdiff_fea_pluszero1 = rdiff_fea_pluszero1.view((-1,) + rdiff_fea_pluszero1.size()[2:])  #bt,c,h,w
        # rdiff_fea_pluszero2 = rdiff_fea_pluszero2.view((-1,) + rdiff_fea_pluszero2.size()[2:])  #bt,c,h,w
        # rdiff_fea_pluszero3 = rdiff_fea_pluszero3.view((-1,) + rdiff_fea_pluszero3.size()[2:])  #bt,c,h,w


        my1 = self.avg_pool(diff_fea_pluszero1)  # bt,c
        # my2 = self.avg_pool(diff_fea_pluszero2)  # bt,c
        # my3 = self.avg_pool(diff_fea_pluszero3)  # bt,c

        rmy1 = self.avg_pool(rdiff_fea_pluszero1)  # bt,c
        # rmy2 = self.avg_pool(rdiff_fea_pluszero2)  # bt,c
        # rmy3 = self.avg_pool(rdiff_fea_pluszero3)  # bt,c


        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        rmy1 = self.Mconv3(rmy1) 
        rmy1 = self.Mbn3(rmy1) 
        rmy1 = self.sigmoid(rmy1) 
        rmy1 = rmy1 - 0.5

        # my2 = self.Mconv3(my2) 
        # my2 = self.Mbn3(my2) 
        # my2 = self.sigmoid(my2) 
        # my2 = my2 - 0.5

        # rmy2 = self.Mconv3(rmy2) 
        # rmy2 = self.Mbn3(rmy2) 
        # rmy2 = self.sigmoid(rmy2) 
        # rmy2 = rmy2 - 0.5

        # my3 = self.Mconv3(my3) 
        # my3 = self.Mbn3(my3) 
        # my3 = self.sigmoid(my3) 
        # my3 = my3 - 0.5

        # rmy3 = self.Mconv3(rmy3) 
        # rmy3 = self.Mbn3(rmy3) 
        # rmy3 = self.sigmoid(rmy3) 
        # rmy3 = rmy3 - 0.5

        #Mars 1:0.3:0.1

        #split 7
        #ilids 1:0.05:0.05  7_2 88.7 100e

        #split 6
        #prid  1:0.3:0.05   97.8 
        # prid split 1:0.3:0.1
           
        output = x + x * (0.5*my1.expand_as(x)+0.5*rmy1.expand_as(x))

        return output
'''

'''
#正反融合的me    
class MEModule(nn.Module):
    #n_segment=4
    def __init__(self, channel, reduction=32, n_segment=4): # ori 32
        print("this is fbme3")
        super(MEModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)

    def forward(self, x):

        #ME Module
        nt, c, h, w = x.size()
        Mbottleneck = self.Mconv1(x) 
        Mbottleneck = self.Mbn1(Mbottleneck)

        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:]) # b,t,c,h,w
        
        Mconv_bottleneck = self.Mconv2(Mbottleneck)    #相减前的卷积 
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])## b,t,c,h,w
        

        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, CMt_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

        __,rMt_fea1 = Mreshape_bottleneck.split([1, self.n_segment-1], dim=1)
        rCMt_fea1,__ = Mreshape_conv_bottleneck.split([self.n_segment-1, 1], dim=1) 

        Mt_fea2, __ = Mreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        __, CMt_fea2 = Mreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1) 

        __,rMt_fea2 = Mreshape_bottleneck.split([2, self.n_segment-2], dim=1)
        rCMt_fea2,__ = Mreshape_conv_bottleneck.split([self.n_segment-2, 2], dim=1) 

        Mt_fea3, __ = Mreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        __, CMt_fea3 = Mreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)

        __,rMt_fea3 = Mreshape_bottleneck.split([3, self.n_segment-3], dim=1)
        rCMt_fea3,__ = Mreshape_conv_bottleneck.split([self.n_segment-3, 3], dim=1)  

        diff_fea1 = CMt_fea1 - Mt_fea1  
        diff_fea2 = CMt_fea2 - Mt_fea2 
        diff_fea3 = CMt_fea3 - Mt_fea3 

        diff_fea1r = rCMt_fea1 - rMt_fea1  
        diff_fea2r = rCMt_fea2 - rMt_fea2 
        diff_fea3r = rCMt_fea3 - rMt_fea3    

        cat13 = torch.cat((diff_fea1,diff_fea3r),dim=1)
        cat22 = torch.cat((diff_fea2,diff_fea2r),dim=1)
        cat31 = torch.cat((diff_fea3,diff_fea1r),dim=1)

        cat13 = cat13.view((-1,) + cat13.size()[2:])  
        cat22 = cat22.view((-1,) + cat22.size()[2:]) 
        cat31 = cat31.view((-1,) + cat31.size()[2:])         

        my1 = self.avg_pool(cat13)  # bt,c
        my2 = self.avg_pool(cat22)  # bt,c
        my3 = self.avg_pool(cat31)  # bt,c

        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        my2 = self.Mconv3(my2) 
        my2 = self.Mbn3(my2) 
        my2 = self.sigmoid(my2) 
        my2 = my2 - 0.5

        my3 = self.Mconv3(my3) 
        my3 = self.Mbn3(my3) 
        my3 = self.sigmoid(my3) 
        my3 = my3 - 0.5
           
        output = x + x * (0.33*my1.expand_as(x)+0.33*my2.expand_as(x)+0.33*my3.expand_as(x))
        return output
'''

'''
#直接双路的ame  top1:89.3% top5:96.8% top10:97.9% mAP:84.7%
class MEModule(nn.Module):
    #n_segment=4
    def __init__(self, channel, reduction=32, n_segment=4): # ori 32
        print("this is a1me3")
        super(MEModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.conv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.bn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.conv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)

        self.Aconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Abn3 = nn.BatchNorm2d(num_features=self.channel)

    def forward(self, x):

        #ME Module
        nt, c, h, w = x.size()
        AMbottleneck = self.conv1(x) 
        AMbottleneck = self.bn1(AMbottleneck)

        AMreshape_bottleneck = AMbottleneck.view((-1, self.n_segment) + AMbottleneck.size()[1:]) # b,t,c,h,w
        
        AMconv_bottleneck = self.conv2(AMbottleneck)    #相减前的卷积 
        AMreshape_conv_bottleneck = AMconv_bottleneck.view((-1, self.n_segment) + AMconv_bottleneck.size()[1:])## b,t,c,h,w
        
        #range 1
        AMt_fea1, __ = AMreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, CAMt_fea1 = AMreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

       
        #range 2
        Mt_fea2, __ = AMreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        __, CMt_fea2 = AMreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1) 

        #range 3
        Mt_fea3, __ = AMreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        __, CMt_fea3 = AMreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)

      
        #motion
        diff_fea1 = CAMt_fea1 - AMt_fea1  
        diff_fea2 = CMt_fea2 - Mt_fea2 
        diff_fea3 = CMt_fea3 - Mt_fea3 

        #appearance
        plus_feat1 = CAMt_fea1 + AMt_fea1 

       

        diff_fea_pluszero1 = F.pad(diff_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        diff_fea_pluszero2 = F.pad(diff_fea2, (0, 0, 0, 0, 0, 0, 0, 2), mode="constant", value=0)
        diff_fea_pluszero3 = F.pad(diff_fea3, (0, 0, 0, 0, 0, 0, 0, 3), mode="constant", value=0)

        diff_fea_pluszero1 = diff_fea_pluszero1.view((-1,) + diff_fea_pluszero1.size()[2:])  
        diff_fea_pluszero2 = diff_fea_pluszero2.view((-1,) + diff_fea_pluszero2.size()[2:])  
        diff_fea_pluszero3 = diff_fea_pluszero3.view((-1,) + diff_fea_pluszero3.size()[2:])  


        plus_fea_pluszero1 = F.pad(plus_feat1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        plus_fea_pluszero1 = plus_fea_pluszero1.view((-1,) + plus_fea_pluszero1.size()[2:])  



        my1 = self.avg_pool(diff_fea_pluszero1)  
        my2 = self.avg_pool(diff_fea_pluszero2)  
        my3 = self.avg_pool(diff_fea_pluszero3)  

        ay1 = self.avg_pool(plus_fea_pluszero1)  

        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        my2 = self.Mconv3(my2) 
        my2 = self.Mbn3(my2) 
        my2 = self.sigmoid(my2) 
        my2 = my2 - 0.5

        my3 = self.Mconv3(my3) 
        my3 = self.Mbn3(my3) 
        my3 = self.sigmoid(my3) 
        my3 = my3 - 0.5

        ay1 = self.Aconv3(ay1) 
        ay1 = self.Abn3(ay1) 
        ay1 = self.sigmoid(ay1) 
        ay1 = ay1 - 0.5

        #Mars 1:0.3:0.1

        output = x + x*(ay1.expand_as(x)) + x * (my1.expand_as(x) + 0.3*my2.expand_as(x) + 0.1*my3.expand_as(x))
        


        return output
'''

'''
#正反考虑前后一帧的ME + 正反考虑前后一帧的ae试试
class MEModule(nn.Module):
    #n_segment=4
    def __init__(self, channel, reduction=32, n_segment=4): # ori 32
        print("this is a1rme3")
        super(MEModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)

        self.Aconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Abn3 = nn.BatchNorm2d(num_features=self.channel)


    def forward(self, x):

        #ME Module
        nt, c, h, w = x.size()
        Mbottleneck = self.Mconv1(x) 
        Mbottleneck = self.Mbn1(Mbottleneck)

        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:]) # b,t,c,h,w
        
        Mconv_bottleneck = self.Mconv2(Mbottleneck)    #相减前的卷积 
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])## b,t,c,h,w
        
        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, CMt_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

        __,rMt_fea1 = Mreshape_bottleneck.split([1, self.n_segment-1], dim=1)
        rCMt_fea1,__ = Mreshape_conv_bottleneck.split([self.n_segment-1, 1], dim=1) 

        diff_fea1 = CMt_fea1 - Mt_fea1  
        diff_fea1r = rCMt_fea1 - rMt_fea1  
        # for ae  add
        add_fea1 = CMt_fea1 + Mt_fea1  
        add_fea1r = rCMt_fea1 + rMt_fea1  

        diff_fea_pluszero1 = F.pad(diff_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        rdiff_fea_pluszero1 = F.pad(diff_fea1r, (0, 0, 0, 0, 0, 0, 1, 0), mode="constant", value=0) 
        diff_fea_pluszero1 = diff_fea_pluszero1.view((-1,) + diff_fea_pluszero1.size()[2:]) 
        rdiff_fea_pluszero1 = rdiff_fea_pluszero1.view((-1,) + rdiff_fea_pluszero1.size()[2:])
        my1 = self.avg_pool(diff_fea_pluszero1)    #换一个pool?
        rmy1 = self.avg_pool(rdiff_fea_pluszero1) 

        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        rmy1 = self.Mconv3(rmy1) 
        rmy1 = self.Mbn3(rmy1) 
        rmy1 = self.sigmoid(rmy1) 
        rmy1 = rmy1 - 0.5



        add_fea_pluszero1 = F.pad(add_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        radd_fea_pluszero1 = F.pad(add_fea1r, (0, 0, 0, 0, 0, 0, 1, 0), mode="constant", value=0)     
        add_fea_pluszero1 = add_fea_pluszero1.view((-1,) + add_fea_pluszero1.size()[2:]) 
        radd_fea_pluszero1 = radd_fea_pluszero1.view((-1,) + radd_fea_pluszero1.size()[2:])
        ay1 = self.avg_pool(add_fea_pluszero1) 
        ray1 =  self.avg_pool(radd_fea_pluszero1) 
       
        # all share
        ay1 = self.Aconv3(ay1) 
        ay1 = self.Abn3(ay1) 
        ay1 = self.sigmoid(ay1) 
        ay1 = ay1 - 0.5

        ray1 = self.Aconv3(ray1) 
        ray1 = self.Abn3(ray1) 
        ray1 = self.sigmoid(ray1) 
        ray1 = ray1 - 0.5

        output = x + x * (0.5*my1.expand_as(x)+0.5*rmy1.expand_as(x)) +x * (0.5*ay1.expand_as(x)+0.5*ray1.expand_as(x))

        return output
'''

'''
#正反降维融合的me    
class MEModule(nn.Module):
    #n_segment=4
    def __init__(self, channel, reduction=32, n_segment=4): # ori 32
        print("this is fbme3")
        super(MEModule, self).__init__()
        
        self.channel = channel
        self.reduction = reduction
        self.n_segment = n_segment
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.sigmoid = nn.Sigmoid()

        #Motion Module
        self.Mconv1 = nn.Conv2d(
            in_channels=self.channel,
            out_channels=self.channel//self.reduction,
            kernel_size=1,
            bias=False)
        self.Mbn1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

        self.Mconv2 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel//self.reduction,
            kernel_size=3,
            padding=1,
            groups=channel//self.reduction,
            bias=False)

        # all share
        self.Mconv3 = nn.Conv2d(
            in_channels=self.channel//self.reduction,
            out_channels=self.channel,
            kernel_size=1,
            bias=False)
        self.Mbn3 = nn.BatchNorm2d(num_features=self.channel)


        #conv down dim
        self.downdim1 = nn.Conv2d(
            in_channels=self.channel//self.reduction*2,
            out_channels=self.channel//self.reduction,
            kernel_size=1)
        self.downdimBN1 = nn.BatchNorm2d(num_features=self.channel//self.reduction)

    def forward(self, x):

        #ME Module
        nt, c, h, w = x.size()
        Mbottleneck = self.Mconv1(x) 
        Mbottleneck = self.Mbn1(Mbottleneck)

        Mreshape_bottleneck = Mbottleneck.view((-1, self.n_segment) + Mbottleneck.size()[1:]) # b,t,c,h,w
        
        Mconv_bottleneck = self.Mconv2(Mbottleneck)    #相减前的卷积 
        Mreshape_conv_bottleneck = Mconv_bottleneck.view((-1, self.n_segment) + Mconv_bottleneck.size()[1:])## b,t,c,h,w
        

        Mt_fea1, __ = Mreshape_bottleneck.split([self.n_segment-1, 1], dim=1)
        __, CMt_fea1 = Mreshape_conv_bottleneck.split([1, self.n_segment-1], dim=1)  

        __,rMt_fea1 = Mreshape_bottleneck.split([1, self.n_segment-1], dim=1)
        rCMt_fea1,__ = Mreshape_conv_bottleneck.split([self.n_segment-1, 1], dim=1) 

        Mt_fea2, __ = Mreshape_bottleneck.split([self.n_segment-2, 2], dim=1) 
        __, CMt_fea2 = Mreshape_conv_bottleneck.split([2, self.n_segment-2], dim=1) 

        __,rMt_fea2 = Mreshape_bottleneck.split([2, self.n_segment-2], dim=1)
        rCMt_fea2,__ = Mreshape_conv_bottleneck.split([self.n_segment-2, 2], dim=1) 

        Mt_fea3, __ = Mreshape_bottleneck.split([self.n_segment-3, 3], dim=1) 
        __, CMt_fea3 = Mreshape_conv_bottleneck.split([3, self.n_segment-3], dim=1)

        __,rMt_fea3 = Mreshape_bottleneck.split([3, self.n_segment-3], dim=1)
        rCMt_fea3,__ = Mreshape_conv_bottleneck.split([self.n_segment-3, 3], dim=1)  

        diff_fea1 = CMt_fea1 - Mt_fea1  
        diff_fea2 = CMt_fea2 - Mt_fea2 
        diff_fea3 = CMt_fea3 - Mt_fea3 

        diff_fea1r = rCMt_fea1 - rMt_fea1  
        diff_fea2r = rCMt_fea2 - rMt_fea2 
        diff_fea3r = rCMt_fea3 - rMt_fea3   


        #先补0
        diff_fea_pluszero1 = F.pad(diff_fea1, (0, 0, 0, 0, 0, 0, 0, 1), mode="constant", value=0) 
        diff_fea_pluszero2 = F.pad(diff_fea2, (0, 0, 0, 0, 0, 0, 0, 2), mode="constant", value=0)
        diff_fea_pluszero3 = F.pad(diff_fea3, (0, 0, 0, 0, 0, 0, 0, 3), mode="constant", value=0)

  
        # --------------------------------------------------------------------------------------------
        diff_fea_pluszero1r = F.pad(diff_fea1r, (0, 0, 0, 0, 0, 0, 1, 0), mode="constant", value=0) 
        diff_fea_pluszero2r = F.pad(diff_fea2r, (0, 0, 0, 0, 0, 0, 2, 0), mode="constant", value=0)
        diff_fea_pluszero3r = F.pad(diff_fea3r, (0, 0, 0, 0, 0, 0, 3, 0), mode="constant", value=0)
 

        #再cat

        diff_fea1 = torch.cat((diff_fea_pluszero1,diff_fea_pluszero3r),dim=2)
        diff_fea2 = torch.cat((diff_fea_pluszero2,diff_fea_pluszero2r),dim=2)
        diff_fea3 = torch.cat((diff_fea_pluszero3,diff_fea_pluszero1r),dim=2)

        diff_fea1 = diff_fea1.view((-1,) + diff_fea1.size()[2:])
        diff_fea2 = diff_fea2.view((-1,) + diff_fea2.size()[2:])
        diff_fea3 = diff_fea3.view((-1,) + diff_fea3.size()[2:]) #bt,c,h,w


        #再降维
        diff_fea1=self.downdim1(diff_fea1)
        diff_fea1=self.downdimBN1(diff_fea1)

        diff_fea2=self.downdim1(diff_fea2)
        diff_fea2=self.downdimBN1(diff_fea2)

        diff_fea3=self.downdim1(diff_fea3)
        diff_fea3=self.downdimBN1(diff_fea3)


        my1 = self.avg_pool(diff_fea1)  # bt,c
        my2 = self.avg_pool(diff_fea2)  # bt,c
        my3 = self.avg_pool(diff_fea3)  # bt,c

        # all share
        my1 = self.Mconv3(my1) 
        my1 = self.Mbn3(my1) 
        my1 = self.sigmoid(my1) 
        my1 = my1 - 0.5

        my2 = self.Mconv3(my2) 
        my2 = self.Mbn3(my2) 
        my2 = self.sigmoid(my2) 
        my2 = my2 - 0.5

        my3 = self.Mconv3(my3) 
        my3 = self.Mbn3(my3) 
        my3 = self.sigmoid(my3) 
        my3 = my3 - 0.5
           
        output = x + x * (0.33*my1.expand_as(x)+0.33*my2.expand_as(x)+0.33*my3.expand_as(x))
        return output
'''

if __name__ =="__main__":
    # pass
    net = MEFBModule(2048)
    x = net(torch.rand(8*4, 2048,16,8))
    print(x.shape)