#test
python test-all.py  --root /media/HDD-2 --arch resnet50 --gpu 0 --resume Mars_ME   --test_epochs  240
python test-all.py  -d duke --root /home/zhangzhengjie/workspace/baseline/datasets --arch resnet50 --gpu 0 --resume DukeV_ME   --test_epochs  240
python test-all.py  -d LSVID --root /home/zhangzhengjie/workspace/baseline/datasets --arch resnet50 --gpu 0 --resume LSVID_base   --test_epochs  240

python test-all_prid_ilids.py  -d ilidsvid --root /home/zhangzhengjie/workspace/baseline/datasets --arch resnet50 --gpu 0 --resume iLIDS_ME   --test_epochs 240  
python test-all_prid_ilids.py  -d prid --root /home/zhangzhengjie/workspace/baseline/datasets --arch resnet50 --gpu 0 --resume prid_ME       --test_epochs 40    


#train
python train.py --root /media/HDD-2 --arch resnet50 --gpu 0 --train_batch 32 --test_batch 32 --stepsize 40 80 120 160 200 --save_dir ./Mars_ME
python train.py -d duke --root /home/zhangzhengjie/workspace/baseline/datasets --arch resnet50 --gpu 0 --train_batch 64 --test_batch 64 --stepsize 40 80 120 160 200 --save_dir ./DukeV_ME
python train.py -d LSVID --root /home/zhangzhengjie/workspace/baseline/datasets --arch resnet50 --gpu 0 --train_batch 64 --test_batch 64 --stepsize 40 80 120 160 200 --save_dir ./LSVID_ME


python train_prid_ilids.py -d ilidsvid --root /home/zhangzhengjie/workspace/baseline/datasets --arch resnet50 --gpu 0,1 --train_batch 32 --test_batch 32 --stepsize 40 80 120 160 200    --save_dir ./iLIDS_ME
python train_prid_ilids.py -d prid --root /home/zhangzhengjie/workspace/baseline/datasets --arch resnet50 --gpu 2,3 --train_batch 32 --test_batch 32 --stepsize 40 80 120 160 200    --save_dir ./prid_ME



单向 ME3
(1 0.5 0.5)
top1:90.2% top5:96.8% top10:97.9% mAP:84.9%
-------------------------------------------
(1 0.3 0.1) 
top1:90.5% top5:97.0% top10:97.8% mAP:84.5%
-------------------------------------------

#当前目标： long range 双向模型  且效果好？？？   ttop1:90.1% top5:96.9% top10:98.1% mAP:85.3%

# 3 Parameter 试一下其他权重 1：0.5：0.5     1：0.3：0.1