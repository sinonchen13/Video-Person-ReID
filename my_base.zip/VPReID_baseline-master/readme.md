# 环境  
python3.6  
pytorch 1.0.1  
torchvision 0.2.1  
# 数据集结构
**--prid_2011**  
&emsp;--prid_2011  
&emsp;&emsp;--single_shot  
&emsp;&emsp;--multi_shot  
&emsp;--splits_prid2011.json  
&emsp;--readme.txt  

**--mars**  
&emsp;--bbox_train  
&emsp;--bbox_test  
&emsp;--info  

**--iLIDS-VID**  
&emsp;--i-LIDS-VID  
&emsp;&emsp;--sequences  
&emsp;&emsp;--images  
&emsp;--train-test people splits  

**--DukeMTMC-VideoReID**  
&emsp;--train  
&emsp;--query  
&emsp;--gallery  
&emsp;--LICENSE_DukeMTMC-VideoReID.txt  
  
**--LS-VID**  
&emsp;--tracklet_val  
&emsp;--tracklet_train  
&emsp;--tracklet_test  
&emsp;--test  
&emsp;--list_sequence  
&emsp;--list_frame  

# 结果
method|&emsp;|prid|iLIDS-VID|MARS|DukeV|LSVID
--|:--:|:--:|:--:|:--:|:--:|:--:|
baseline|R1|89.88|73.33|88.58|95.01|77.31
&emsp; |mAP|--|--|81.41|93.19|62.97
random|R1|84.26|70.66|95.50|95.72|91.58
&emsp;|mAP|--|--|87.64|94.21|83.14

# 运行方式
python create_xxxx_database.py  
运行 sh文件   
random脚本在sh文件中为注释

# 参考
https://github.com/jackie840129/STE-NVAN  
https://github.com/jiyanggao/Video-Person-ReID  
https://github.com/daizuozhuo/batch-dropblock-network
