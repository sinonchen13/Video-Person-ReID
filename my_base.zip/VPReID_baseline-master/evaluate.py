from util import utils
from util.cmc import Video_Cmc,Video_Cmc_iLIDS_prid
from net import models
import parser
import sys
import random
from tqdm import tqdm
import numpy as np
import math
import iLIDS
import prid
import torch
import torch.nn as nn
import transforms as T
import torch.backends.cudnn as cudnn
cudnn.benchmark=True
import os
os.environ['CUDA_VISIBLE_DEVICES']='0'
torch.multiprocessing.set_sharing_strategy('file_system')
##############################################################
#new test
def extract(model, vids, use_gpu):
    n, c, f, h, w = vids.size()
    
    assert(n == 1)

    if use_gpu:
        feat = torch.cuda.FloatTensor()
    else:
        feat = torch.FloatTensor()
    for i in range(math.ceil(f/32)):
        clip = vids[:, :, i*32:(i+1)*32, :, :]
        
        if use_gpu:
            clip = clip.cuda()
    
        b,c,t,h,w=clip.shape
        clip=clip.permute(0,2,1,3,4).contiguous()
        clip = clip.reshape(b*t,c,h,w)
        
        output = model(clip)
        
        feat = torch.cat((feat, output), 0)
        
    feat = feat.mean(0)
    # feat = model.bn(feat)

    feat = feat.data.cpu()
 
    return feat


def test(model, queryloader, galleryloader, use_gpu):
    since = time.time()
    model.eval()

    qf, q_pids, q_camids = [], [], []
    for batch_idx, (vids, pids, camids) in enumerate(queryloader):
        if (batch_idx + 1) % 1000==0:
            print("{}/{}".format(batch_idx+1, len(queryloader)))

        qf.append(extract(model, vids, use_gpu).squeeze())
        q_pids.extend(pids)
        q_camids.extend(camids)

    qf = torch.stack(qf)
    q_pids = np.asarray(q_pids)
    q_camids = np.asarray(q_camids)
    print("Extracted features for query set, obtained {} matrix".format(qf.shape))

    gf, g_pids, g_camids = [], [], []
    for batch_idx, (vids, pids, camids) in enumerate(galleryloader):
        if (batch_idx + 1) % 1000==0:
            print("{}/{}".format(batch_idx+1, len(galleryloader)))

        gf.append(extract(model, vids, use_gpu).squeeze())
        g_pids.extend(pids)
        g_camids.extend(camids)
    gf = torch.stack(gf)
    g_pids = np.asarray(g_pids)
    g_camids = np.asarray(g_camids)
    dataset='mars'
    if dataset == 'mars':
        # gallery set must contain query set, otherwise 140 query imgs will not have ground truth.
        gf = torch.cat((qf, gf), 0)
        g_pids = np.append(q_pids, g_pids)
        g_camids = np.append(q_camids, g_camids)

    print("Extracted features for gallery set, obtained {} matrix".format(gf.shape))

    time_elapsed = time.time() - since
    print('Extracting features complete in {:.0f}m {:.0f}s'.format(time_elapsed // 60, time_elapsed % 60))

    print("Computing distance matrix")
    m, n = qf.size(0), gf.size(0)
    distmat = torch.zeros((m,n))
    distance = 'euclidean'
    if distance == 'euclidean':
        distmat = torch.pow(qf, 2).sum(dim=1, keepdim=True).expand(m, n) + \
                  torch.pow(gf, 2).sum(dim=1, keepdim=True).expand(n, m).t()
        for i in range(m):
            distmat[i:i+1].addmm_(1, -2, qf[i:i+1], gf.t())
    else:
        q_norm = torch.norm(qf, p=2, dim=1, keepdim=True)
        g_norm = torch.norm(gf, p=2, dim=1, keepdim=True)
        qf = qf.div(q_norm.expand_as(qf))
        gf = gf.div(g_norm.expand_as(gf))
        for i in range(m):
            distmat[i] = - torch.mm(qf[i:i+1], gf.t())
    distmat = distmat.numpy()

    print("Computing CMC and mAP")
    cmc, mAP = evaluate(distmat, q_pids, g_pids, q_camids, g_camids)

    print("Results ----------")
    print('top1:{:.1%} top5:{:.1%} top10:{:.1%} mAP:{:.1%}'.format(cmc[0],cmc[4],cmc[9],mAP))
    print("------------------")

    return cmc[0]




#############################################################
def validation_iLIDS_prid(network,query_dataloader,gallery_dataloader,args):
    network.eval()
    gallery_features = []
    gallery_labels = []
    gallery_cams = []
    with torch.no_grad():
        for c,data in enumerate(gallery_dataloader):
            #print(c)
            seqs = data[0].cuda()
            label = data[1]
            cams = data[2]
            
            feat = network(seqs)
            
            gallery_features.append(feat.cpu())
            gallery_labels.append(label)
            gallery_cams.append(cams)

    gallery_features = torch.cat(gallery_features,dim=0).numpy()
    gallery_labels = torch.cat(gallery_labels,dim=0).numpy()
    gallery_cams = torch.cat(gallery_cams,dim=0).numpy()

    query_features = []
    query_labels = []
    query_cams = []
    with torch.no_grad():
        for c,data in enumerate(query_dataloader):
            #print(c)
            seqs = data[0].cuda()
            label = data[1]
            cams = data[2]
            
            feat = network(seqs)
            
            query_features.append(feat.cpu())
            query_labels.append(label)
            query_cams.append(cams)

    query_features = torch.cat(query_features,dim=0).numpy()
    query_labels = torch.cat(query_labels,dim=0).numpy()
    query_cams = torch.cat(query_cams,dim=0).numpy()

    Cmc,mAP = Video_Cmc_iLIDS_prid(gallery_features,gallery_labels,gallery_cams,query_features,query_labels,query_cams,10000)
    network.train()

    return Cmc[0],mAP
def validation_DukeV_Mars_LSVID(network,dataloader,args):
    network.eval() 
    gallery_features = []
    gallery_labels = []
    gallery_cams = []
    with torch.no_grad():
        for c,data in enumerate(dataloader):
            seqs = data[0].cuda()
            label = data[1]
            cams = data[2]

            feat = network(seqs)
            gallery_features.append(feat.cpu())
            gallery_labels.append(label)
            gallery_cams.append(cams)
            
    

    gallery_features = torch.cat(gallery_features,dim=0).numpy()
    cols,dims=gallery_features.shape
    
    gallery_labels = torch.cat(gallery_labels,dim=0).numpy()
    gallery_cams = torch.cat(gallery_cams,dim=0).numpy()
    if(args.datasets=='LSVID'):
        #remove added last one
        gallery_features = gallery_features[:cols-1,:]
        gallery_labels = gallery_labels[:cols-1]
        gallery_cams = gallery_cams[:cols-1]
    
    Cmc,mAP = Video_Cmc(gallery_features,gallery_labels,gallery_cams,dataloader.dataset.query_idx,10000)
    network.train()

    return Cmc[0],mAP

if __name__ == '__main__':
    #Parse args
    args = parser.parse_args()

    # train_transform = T.Compose([T.Resize((256,128)),T.ToTensor(),T.Normalize(mean=[0.485,0.456,0.406],std=[0.229,0.224,0.225]),T.RandomErasing()])
    # test_transform = T.Compose([T.Resize((256,128)),T.ToTensor(),T.Normalize(mean=[0.485,0.456,0.406],std=[0.229,0.224,0.225])])

    # print('Start dataloader...')
    # print('cur dataset: ',args.datasets)
    # if args.datasets=="Mars":
    #     train_dataloader = utils.Get_Video_train_DataLoader(args.train_txt,args.train_info,train_transform,shuffle=True,num_workers=args.num_workers,\
    #                                                     S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
    #     num_class = train_dataloader.dataset.n_id
    #     test_dataloader = utils.Get_Video_test_DataLoader(args.test_txt,args.test_info,args.query_info,test_transform,batch_size=args.batch_size,\
    #                                              shuffle=False,num_workers=args.num_workers,S=args.S,distractor=True,dataset=args.datasets)
    # elif args.datasets=='LSVID':
    #     train_dataloader = utils.Get_Video_train_DataLoader(args.train_txt,args.train_info,train_transform,shuffle=True,num_workers=args.num_workers,\
    #                                                     S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
    #     num_class = train_dataloader.dataset.n_id
    #     test_dataloader = utils.Get_Video_test_DataLoader(args.test_txt,args.test_info,args.query_info,test_transform,batch_size=args.batch_size,\
    #                                              shuffle=False,num_workers=args.num_workers,S=args.S,distractor=True,dataset=args.datasets)
    # elif args.datasets=='DukeV':
    #     train_dataloader = utils.Get_Video_train_DataLoader(args.train_txt,args.train_info,train_transform,shuffle=True,num_workers=args.num_workers,\
    #                                                     S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
    #     num_class = train_dataloader.dataset.n_id
    #     test_dataloader = utils.Get_Video_test_DataLoader(args.test_txt,args.test_info,args.query_info,test_transform,batch_size=args.batch_size,\
    #                                              shuffle=False,num_workers=args.num_workers,S=args.S,distractor=True,dataset=args.datasets)
    # elif args.datasets=="iLIDS-VID":
    #     train_dataloader,num_class = iLIDS.Get_Video_train_DataLoader_iLIDS_VID(train_transform, shuffle=True,num_workers=args.num_workers,\
    #                                                     S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
    #     query_dataloader = iLIDS.Get_Video_query_DataLoader_iLIDS_VID(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
    #     gallery_dataloader=iLIDS.Get_Video_gallery_DataLoader_iLIDS_VID(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
    # elif args.datasets=="prid":
    #     train_dataloader,num_class = prid.Get_Video_train_DataLoader_prid(train_transform, shuffle=True,num_workers=args.num_workers,\
    #                                                     S=args.S,track_per_class=args.track_per_class,class_per_batch=args.class_per_batch)
    #     query_dataloader = prid.Get_Video_query_DataLoader_prid(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
    #     gallery_dataloader=prid.Get_Video_gallery_DataLoader_prid(test_transform,batch_size=args.batch_size,shuffle=False,num_workers=args.num_workers,S=args.S)
    # print('End dataloader...\n')
    
    #new test
    import spatial_transforms as ST
    import temporal_transforms as TT
    import data_manager as data_manager
    from video_loader import VideoDataset
    from eval_metrics import evaluate
    from torch.utils.data import DataLoader
    import time
    use_gpu = torch.cuda.is_available()

    dataset = data_manager.init_dataset(name='mars', root='/media/HDD-2')

    # Data augmentation
    spatial_transform_test = ST.Compose([
                ST.Scale((256,128), interpolation=3),
                ST.ToTensor(),
                ST.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ])
    temporal_transform_test = None

    pin_memory = True if use_gpu else False

    queryloader = DataLoader(
        VideoDataset(dataset.query, spatial_transform=spatial_transform_test, temporal_transform=temporal_transform_test),
        batch_size=1, shuffle=False, num_workers=0,
        pin_memory=pin_memory, drop_last=False)

    galleryloader = DataLoader(
        VideoDataset(dataset.gallery, spatial_transform=spatial_transform_test, temporal_transform=temporal_transform_test),
        batch_size=1, shuffle=False, num_workers=0,
        pin_memory=pin_memory, drop_last=False)
    
    # network = nn.DataParallel(models.CNN(args.latent_dim,num_class=num_class,stride=args.stride,tracklet_len=args.S,random=args.random).cuda())
    network = nn.DataParallel(models.CNN(args.latent_dim,num_class=dataset.num_train_pids,stride=args.stride,tracklet_len=args.S,random=args.random)).cuda()

    if args.load_ckpt is  None:
        print('No ckpt!')
        exit()
    else:
        state = torch.load(args.load_ckpt)
        network.load_state_dict(state,strict=True)
    with torch.no_grad():
        test(network, queryloader, galleryloader, use_gpu)

    # if(args.datasets=='DukeV' or args.datasets=='Mars' or args.datasets=='LSVID' ):
    #     cmc,map = validation_DukeV_Mars_LSVID(network,test_dataloader,args)
    # if args.datasets == 'iLIDS-VID' or args.datasets == 'prid':
    #     cmc,map = validation_iLIDS_prid(network,query_dataloader,gallery_dataloader,args)


    # print('CMC : %.4f , mAP : %.4f'%(cmc,map))
