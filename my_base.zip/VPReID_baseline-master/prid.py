from __future__ import print_function, absolute_import
import os
import glob
import re
import sys
import urllib
import tarfile
import zipfile
import os.path as osp
from scipy.io import loadmat
import numpy as np
import warnings
import random
import torch
from util.utils import mkdir_if_missing, write_json, read_json
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import SubsetRandomSampler
import math
from PIL import Image


class Video_query_Dataset_prid(Dataset):
    def __init__(self,transform,S,root):
        super().__init__()
        #self.root = '/media/sdb1/zzj/VPReID_datasets/prid_2011'
        self.root=root
        self.split_id=0
        self.split_path = osp.join(self.root, 'splits_prid2011.json')
        self.cam_a_path = osp.join(self.root, 'prid_2011', 'multi_shot', 'cam_a')
        self.cam_b_path = osp.join(self.root, 'prid_2011', 'multi_shot', 'cam_b')

        self.transform =transform
        self.S=S
       
        self.flip_p=0.5

        
        splits = read_json(self.split_path)
        if self.split_id >= len(splits):
            raise ValueError("split_id exceeds range, received {}, but expected between 0 and {}".format(self.split_id, len(splits)-1))
        split = splits[self.split_id]
        train_dirs, test_dirs = split['train'], split['test']
        #print("# train identites: {}, # test identites {}".format(len(train_dirs), len(test_dirs)))

       
        query = self._process_data(test_dirs, cam1=True, cam2=False)
        self.query = np.array(query)
       
    def __getitem__(self,idx):
        clips = self.query[idx,0]
        imgs = [self.transform(Image.open(path)) for path in clips[:,0]]
        imgs = torch.stack(imgs,dim=0)
        label = self.query[idx,1]*torch.ones(1,dtype=torch.int32)
        cam = self.query[idx,2]*torch.ones(1,dtype=torch.int32)
        return imgs,label,cam

    def __len__(self):
        return len(self.query)
    
    def _process_data(self, dirnames, cam1=True, cam2=True):
           
        tracklets = []
        dirname2pid = {dirname:i for i, dirname in enumerate(dirnames)}
        for dirname in dirnames:
            if cam1:
                person_dir = osp.join(self.cam_a_path, dirname)
                
                img_names = glob.glob(osp.join(person_dir, '*.png'))
                assert len(img_names) > 0
                sample_clip = []
                F = len(img_names)
                if F < self.S:
                    strip =img_names+[img_names[-1]]*(self.S-F)
                    for s in range(self.S):
                        pool = strip[s*1:(s+1)*1]
                        sample_clip.append(list(pool))
                else:
                    interval = math.ceil(F/self.S)
                    strip = img_names+[img_names[-1]]*(interval*self.S-F)
                    for s in range(self.S):
                        pool = strip[s*interval:(s+1)*interval]
                        sample_clip.append(list(pool))
                pid = dirname2pid[dirname]
                tracklets.append(np.array([np.array(sample_clip), pid, 0]))
                

            if cam2:
                person_dir = osp.join(self.cam_b_path, dirname)
                
                img_names = glob.glob(osp.join(person_dir, '*.png'))
                assert len(img_names) > 0
                sample_clip = []
                F = len(img_names)
                if F < self.S:
                    strip =img_names+[img_names[-1]]*(self.S-F)
                    for s in range(self.S):
                        pool = strip[s*1:(s+1)*1]
                        sample_clip.append(list(pool))
                else:
                    interval = math.ceil(F/self.S)
                    strip = img_names+[img_names[-1]]*(interval*self.S-F)
                    for s in range(self.S):
                        pool = strip[s*interval:(s+1)*interval]
                        sample_clip.append(list(pool))
                pid = dirname2pid[dirname]
                tracklets.append(np.array([np.array(sample_clip), pid, 1]))
        return tracklets

class Video_gallery_Dataset_prid(Dataset):
    
    def __init__(self,transform,S,root):
        super().__init__()
        #self.root = '/media/sdb1/zzj/VPReID_datasets/prid_2011'
        self.root=root
        self.split_id=0
        self.split_path = osp.join(self.root, 'splits_prid2011.json')
        self.cam_a_path = osp.join(self.root, 'prid_2011', 'multi_shot', 'cam_a')
        self.cam_b_path = osp.join(self.root, 'prid_2011', 'multi_shot', 'cam_b')

        self.transform =transform
        self.S=S
        
        self.flip_p=0.5

        
        splits = read_json(self.split_path)
        if self.split_id >= len(splits):
            raise ValueError("split_id exceeds range, received {}, but expected between 0 and {}".format(self.split_id, len(splits)-1))
        split = splits[self.split_id]
        train_dirs, test_dirs = split['train'], split['test']
        #print("# train identites: {}, # test identites {}".format(len(train_dirs), len(test_dirs)))

        gallery = self._process_data(test_dirs, cam1=False, cam2=True)
        self.gallery = np.array(gallery)

    def __getitem__(self,idx):
        clips = self.gallery[idx,0]
        imgs = [self.transform(Image.open(path)) for path in clips[:,0]]
        imgs = torch.stack(imgs,dim=0)
        label = self.gallery[idx,1]*torch.ones(1,dtype=torch.int32)
        cam = self.gallery[idx,2]*torch.ones(1,dtype=torch.int32)
        return imgs,label,cam

    def __len__(self):
        return len(self.gallery)

    def _process_data(self, dirnames, cam1=True, cam2=True):
        tracklets = []
        dirname2pid = {dirname:i for i, dirname in enumerate(dirnames)}
        for dirname in dirnames:
            if cam1:
                person_dir = osp.join(self.cam_a_path, dirname)
                
                img_names = glob.glob(osp.join(person_dir, '*.png'))
                assert len(img_names) > 0
                sample_clip = []
                F = len(img_names)
                if F < self.S:
                    strip =img_names+[img_names[-1]]*(self.S-F)
                    for s in range(self.S):
                        pool = strip[s*1:(s+1)*1]
                        sample_clip.append(list(pool))
                else:
                    interval = math.ceil(F/self.S)
                    strip = img_names+[img_names[-1]]*(interval*self.S-F)
                    for s in range(self.S):
                        pool = strip[s*interval:(s+1)*interval]
                        sample_clip.append(list(pool))
                pid = dirname2pid[dirname]
                tracklets.append(np.array([np.array(sample_clip), pid, 0]))
                

            if cam2:
                person_dir = osp.join(self.cam_b_path, dirname)
                
                img_names = glob.glob(osp.join(person_dir, '*.png'))
                assert len(img_names) > 0
                sample_clip = []
                F = len(img_names)
                if F < self.S:
                    strip =img_names+[img_names[-1]]*(self.S-F)
                    for s in range(self.S):
                        pool = strip[s*1:(s+1)*1]
                        sample_clip.append(list(pool))
                else:
                    interval = math.ceil(F/self.S)
                    strip = img_names+[img_names[-1]]*(interval*self.S-F)
                    for s in range(self.S):
                        pool = strip[s*interval:(s+1)*interval]
                        sample_clip.append(list(pool))
                pid = dirname2pid[dirname]
                tracklets.append(np.array([np.array(sample_clip), pid, 1]))
        return tracklets

class Video_train_Dataset_prid(Dataset):
    def __init__(self,transform,S,track_per_class,root):
        super().__init__()
        #self.root = '/media/sdb1/zzj/VPReID_datasets/prid_2011'
        self.root=root
        self.split_id=0
        self.split_path = osp.join(self.root, 'splits_prid2011.json')
        self.cam_a_path = osp.join(self.root, 'prid_2011', 'multi_shot', 'cam_a')
        self.cam_b_path = osp.join(self.root, 'prid_2011', 'multi_shot', 'cam_b')

        self.transform =transform
        self.S=S
        self.track_per_class=track_per_class
        self.flip_p=0.5

        
        splits = read_json(self.split_path)
        if self.split_id >= len(splits):
            raise ValueError("split_id exceeds range, received {}, but expected between 0 and {}".format(self.split_id, len(splits)-1))
        split = splits[self.split_id]
        train_dirs, test_dirs = split['train'], split['test']
        #print("# train identites: {}, # test identites {}".format(len(train_dirs), len(test_dirs)))

        train = self._process_data(train_dirs, cam1=True, cam2=True)
        self.n_id =len(train)
        self.train = np.array(train)

    def __getitem__(self,ID):
        sub_info = self.train[self.train[:,1] == ID]
        tracks_pool = sub_info[:,0]
        one_id_tracks = []
        for track_pool in tracks_pool:
            idx = np.random.choice(track_pool.shape[1],track_pool.shape[0])
            imgs_path = track_pool[np.arange(len(track_pool)),idx]
            imgs = [self.transform(Image.open(path)) for path in imgs_path]
            imgs = torch.stack(imgs,dim=0)

            random_p = random.random()
            if random_p  < self.flip_p:
                imgs = torch.flip(imgs,dims=[3])
            one_id_tracks.append(imgs)
        return torch.stack(one_id_tracks,dim=0), ID*torch.ones(self.track_per_class,dtype=torch.int64)
    
    def __len__(self):
        return len(self.train)//2

    def _process_data(self, dirnames, cam1=True, cam2=True):
        tracklets = []
        dirname2pid = {dirname:i for i, dirname in enumerate(dirnames)}
        for dirname in dirnames:
            if cam1:
                person_dir = osp.join(self.cam_a_path, dirname)
                
                img_names = glob.glob(osp.join(person_dir, '*.png'))
                assert len(img_names) > 0
                sample_clip = []
                F = len(img_names)
                if F < self.S:
                    strip =img_names+[img_names[-1]]*(self.S-F)
                    for s in range(self.S):
                        pool = strip[s*1:(s+1)*1]
                        sample_clip.append(list(pool))
                else:
                    interval = math.ceil(F/self.S)
                    strip = img_names+[img_names[-1]]*(interval*self.S-F)
                    for s in range(self.S):
                        pool = strip[s*interval:(s+1)*interval]
                        sample_clip.append(list(pool))
                pid = dirname2pid[dirname]
                tracklets.append(np.array([np.array(sample_clip), pid, 0]))
                

            if cam2:
                person_dir = osp.join(self.cam_b_path, dirname)
                
                img_names = glob.glob(osp.join(person_dir, '*.png'))
                assert len(img_names) > 0
                sample_clip = []
                F = len(img_names)
                if F < self.S:
                    strip =img_names+[img_names[-1]]*(self.S-F)
                    for s in range(self.S):
                        pool = strip[s*1:(s+1)*1]
                        sample_clip.append(list(pool))
                else:
                    interval = math.ceil(F/self.S)
                    strip = img_names+[img_names[-1]]*(interval*self.S-F)
                    for s in range(self.S):
                        pool = strip[s*interval:(s+1)*interval]
                        sample_clip.append(list(pool))
                pid = dirname2pid[dirname]
                tracklets.append(np.array([np.array(sample_clip), pid, 1]))
        return tracklets



def Video_query_collate_fn(data):
    imgs,label,cam= zip(*data)
    imgs = torch.cat(imgs,dim=0)
    labels = torch.cat(label,dim=0)
    cams = torch.cat(cam,dim=0)
    return imgs,labels,cams

def Video_gallery_collate_fn(data):
    imgs,label,cam= zip(*data)
    imgs = torch.cat(imgs,dim=0)
    labels = torch.cat(label,dim=0)
    cams = torch.cat(cam,dim=0)
    return imgs,labels,cams

def Video_train_collate_fn(data):
    imgs,labels = zip(*data)
    imgs = torch.cat(imgs,dim=0)
    labels = torch.cat(labels,dim=0)
    return imgs,labels



def Get_Video_query_DataLoader_prid(transform,batch_size=32,shuffle=False,num_workers=4,S=8,root='/media/sdb1/zzj/VPReID_datasets/prid_2011'):
    dataset = Video_query_Dataset_prid(transform=transform,S=S,root=root)
    dataloader = DataLoader(dataset,batch_size=batch_size,collate_fn=Video_query_collate_fn,shuffle=shuffle,worker_init_fn=lambda _:np.random.seed(),num_workers=num_workers)
    return dataloader

def Get_Video_gallery_DataLoader_prid(transform,batch_size=32,shuffle=False,num_workers=4,S=8,root='/media/sdb1/zzj/VPReID_datasets/prid_2011'):
    dataset = Video_gallery_Dataset_prid(transform=transform,S=S,root=root)
    dataloader = DataLoader(dataset,batch_size=batch_size,collate_fn=Video_gallery_collate_fn,shuffle=shuffle,worker_init_fn=lambda _:np.random.seed(),num_workers=num_workers)
    return dataloader

def Get_Video_train_DataLoader_prid(transform,shuffle=True,num_workers=4,S=8,track_per_class=2,class_per_batch=8,root='/media/sdb1/zzj/VPReID_datasets/prid_2011'):
    dataset = Video_train_Dataset_prid(transform=transform,S=S,track_per_class=track_per_class,root=root)
    dataloader = DataLoader(dataset,batch_size=class_per_batch,collate_fn=Video_train_collate_fn,shuffle=shuffle,worker_init_fn=lambda _:np.random.seed(),drop_last=True,num_workers=num_workers)
    return dataloader,dataset.n_id


if __name__ == "__main__":
    pass
